export interface TransmissionConfig {
  baudRate: number
  port: string | null
  isConnected: boolean
}

export interface SignalPacket {
  type: 'signal_data' | 'config' | 'control'
  timestamp: number
  data: any
}

export class SignalTransmitter {
  private port: SerialPort | null = null
  private writer: WritableStreamDefaultWriter | null = null
  private reader: ReadableStreamDefaultReader | null = null
  private isConnected: boolean = false
  private config: TransmissionConfig = {
    baudRate: 115200,
    port: null,
    isConnected: false
  }

  private connectBtn: HTMLButtonElement
  private disconnectBtn: HTMLButtonElement
  private transmitBtn: HTMLButtonElement
  private statusSpan: HTMLSpanElement
  private baudRateSelect: HTMLSelectElement
  private transmissionLog: HTMLElement

  constructor() {
    this.initializeElements()
    this.setupEventListeners()
    this.updateUI()
  }

  private initializeElements(): void {
    this.connectBtn = document.getElementById('connect-esp32-btn') as HTMLButtonElement
    this.disconnectBtn = document.getElementById('disconnect-esp32-btn') as HTMLButtonElement
    this.transmitBtn = document.getElementById('transmit-signals-btn') as HTMLButtonElement
    this.statusSpan = document.getElementById('connection-status') as HTMLSpanElement
    this.baudRateSelect = document.getElementById('baud-rate') as HTMLSelectElement
    this.transmissionLog = document.getElementById('transmission-log') as HTMLElement
  }

  private setupEventListeners(): void {
    if (this.connectBtn) {
      this.connectBtn.addEventListener('click', () => this.connectToESP32())
    }
    if (this.disconnectBtn) {
      this.disconnectBtn.addEventListener('click', () => this.disconnectFromESP32())
    }
    if (this.transmitBtn) {
      this.transmitBtn.addEventListener('click', () => this.transmitCurrentSignals())
    }
    
    if (this.baudRateSelect) {
      this.baudRateSelect.addEventListener('change', () => {
        this.config.baudRate = parseInt(this.baudRateSelect.value)
        console.log('Baud rate changed to:', this.config.baudRate)
      })
    }
  }

  public async connectToESP32(): Promise<boolean> {
    if (!('serial' in navigator)) {
      this.logMessage('Web Serial API not supported in this browser', 'error')
      return false
    }

    try {
      // Request serial port
      this.port = await (navigator as any).serial.requestPort()
      
      // Open the port
      await this.port.open({ 
        baudRate: this.config.baudRate,
        dataBits: 8,
        stopBits: 1,
        parity: 'none'
      })

      this.writer = this.port.writable.getWriter()
      this.reader = this.port.readable.getReader()
      
      this.isConnected = true
      this.config.isConnected = true
      this.updateUI()
      
      this.logMessage('Connected to ESP32 successfully', 'success')
      
      // Start reading responses
      this.startReading()
      
      // Send initial handshake
      await this.sendHandshake()
      
      return true
    } catch (error) {
      this.logMessage(`Connection failed: ${error}`, 'error')
      return false
    }
  }

  public async disconnectFromESP32(): Promise<void> {
    try {
      if (this.writer) {
        await this.writer.close()
        this.writer = null
      }
      
      if (this.reader) {
        await this.reader.cancel()
        this.reader = null
      }
      
      if (this.port) {
        await this.port.close()
        this.port = null
      }
      
      this.isConnected = false
      this.config.isConnected = false
      this.updateUI()
      
      this.logMessage('Disconnected from ESP32', 'info')
    } catch (error) {
      this.logMessage(`Disconnection error: ${error}`, 'error')
    }
  }

  private async startReading(): Promise<void> {
    if (!this.reader) return

    try {
      while (this.isConnected) {
        const { value, done } = await this.reader.read()
        if (done) break

        const text = new TextDecoder().decode(value)
        this.handleESP32Response(text)
      }
    } catch (error) {
      if (this.isConnected) {
        this.logMessage(`Reading error: ${error}`, 'error')
      }
    }
  }

  private handleESP32Response(response: string): void {
    const lines = response.trim().split('\n')
    
    for (const line of lines) {
      if (line.trim()) {
        this.logMessage(`ESP32: ${line}`, 'received')
        
        // Handle specific responses
        if (line.includes('READY')) {
          this.logMessage('ESP32 is ready to receive signals', 'success')
        } else if (line.includes('SIGNAL_SAVED')) {
          this.logMessage('Signal pattern saved to SD card', 'success')
        } else if (line.includes('ERROR')) {
          this.logMessage(`ESP32 Error: ${line}`, 'error')
        }
      }
    }
  }

  private async sendHandshake(): Promise<void> {
    const handshake = {
      type: 'handshake',
      timestamp: Date.now(),
      data: {
        app: 'Automotive Signal Generator',
        version: '1.0',
        developer: 'SALAH ALRAWI'
      }
    }
    
    await this.sendPacket(handshake)
  }

  public async transmitCurrentSignals(): Promise<void> {
    if (!this.isConnected) {
      this.logMessage('Not connected to ESP32', 'error')
      return
    }

    try {
      // Get current signal data from canvas renderer
      const signalData = this.getSignalDataFromRenderer()
      
      if (!signalData) {
        this.logMessage('No signal data available to transmit', 'error')
        return
      }

      this.logMessage('Transmitting signal data to ESP32...', 'info')

      // Send signal configuration
      const configPacket = {
        type: 'config',
        timestamp: Date.now(),
        data: {
          rpm: signalData.rpm,
          signalType: signalData.signalType,
          vehicle: signalData.vehicle
        }
      }
      
      await this.sendPacket(configPacket)
      await this.delay(100)

      // Send signal data in chunks
      await this.sendSignalDataInChunks(signalData)
      
      // Send completion signal
      const completePacket = {
        type: 'control',
        timestamp: Date.now(),
        data: { command: 'SIGNAL_COMPLETE' }
      }
      
      await this.sendPacket(completePacket)
      
      this.logMessage('Signal transmission completed', 'success')
      
    } catch (error) {
      this.logMessage(`Transmission error: ${error}`, 'error')
    }
  }

  private async sendSignalDataInChunks(signalData: any): Promise<void> {
    const chunkSize = 50 // Send 50 values at a time
    
    // Send crank signal
    await this.sendSignalChunks('crank', signalData.crank, chunkSize)
    await this.delay(50)
    
    // Send cam1 signal
    await this.sendSignalChunks('cam1', signalData.cam1, chunkSize)
    await this.delay(50)
    
    // Send cam2 signal
    await this.sendSignalChunks('cam2', signalData.cam2, chunkSize)
  }

  private async sendSignalChunks(signalName: string, signalArray: number[], chunkSize: number): Promise<void> {
    for (let i = 0; i < signalArray.length; i += chunkSize) {
      const chunk = signalArray.slice(i, i + chunkSize)
      
      const packet = {
        type: 'signal_data',
        timestamp: Date.now(),
        data: {
          signal: signalName,
          chunk: i / chunkSize,
          total_chunks: Math.ceil(signalArray.length / chunkSize),
          values: chunk
        }
      }
      
      await this.sendPacket(packet)
      await this.delay(20) // Small delay between chunks
      
      this.logMessage(`Sent ${signalName} chunk ${Math.floor(i / chunkSize) + 1}/${Math.ceil(signalArray.length / chunkSize)}`, 'info')
    }
  }

  private async sendPacket(packet: SignalPacket): Promise<void> {
    if (!this.writer) throw new Error('No writer available')
    
    const jsonData = JSON.stringify(packet) + '\n'
    const encoder = new TextEncoder()
    const data = encoder.encode(jsonData)
    
    await this.writer.write(data)
  }

  private getSignalDataFromRenderer(): any {
    // This will be connected to the canvas renderer
    const canvasRenderer = (window as any).canvasRenderer
    if (!canvasRenderer) return null

    const signalData = canvasRenderer.getSignalData()
    const signalGenerator = (window as any).signalGenerator
    
    return {
      crank: signalData.crank,
      cam1: signalData.cam1,
      cam2: signalData.cam2,
      rpm: signalGenerator ? signalGenerator.getConfig().rpm : 1000,
      signalType: signalGenerator ? signalGenerator.getConfig().signalType : 'square',
      vehicle: this.getCurrentVehicleInfo()
    }
  }

  private getCurrentVehicleInfo(): any {
    const brandSelect = document.getElementById('brand') as HTMLSelectElement
    const modelSelect = document.getElementById('model') as HTMLSelectElement
    const yearSelect = document.getElementById('year') as HTMLSelectElement
    const engineSelect = document.getElementById('engine') as HTMLSelectElement
    
    return {
      brand: brandSelect?.value || 'Unknown',
      model: modelSelect?.value || 'Unknown',
      year: yearSelect?.value || 'Unknown',
      engine: engineSelect?.value || 'Unknown'
    }
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms))
  }

  private updateUI(): void {
    if (this.connectBtn) {
      this.connectBtn.disabled = this.isConnected
    }
    if (this.disconnectBtn) {
      this.disconnectBtn.disabled = !this.isConnected
    }
    if (this.transmitBtn) {
      this.transmitBtn.disabled = !this.isConnected
    }
    
    if (this.statusSpan) {
      this.statusSpan.textContent = this.isConnected ? 'Connected' : 'Disconnected'
      this.statusSpan.style.color = this.isConnected ? '#10b981' : '#ef4444'
    }
  }

  private logMessage(message: string, type: 'info' | 'success' | 'error' | 'received' = 'info'): void {
    const timestamp = new Date().toLocaleTimeString()
    const logEntry = document.createElement('div')
    logEntry.className = `log-entry log-${type}`
    
    const colors = {
      info: '#2563eb',
      success: '#10b981',
      error: '#ef4444',
      received: '#f59e0b'
    }
    
    logEntry.style.cssText = `
      padding: 0.5rem;
      margin: 0.25rem 0;
      border-left: 3px solid ${colors[type]};
      background: rgba(0,0,0,0.05);
      font-family: 'Courier New', monospace;
      font-size: 0.875rem;
      border-radius: 4px;
    `
    
    logEntry.innerHTML = `<span style="color: #666;">[${timestamp}]</span> ${message}`
    
    this.transmissionLog.appendChild(logEntry)
    this.transmissionLog.scrollTop = this.transmissionLog.scrollHeight
    
    // Keep only last 100 log entries
    while (this.transmissionLog.children.length > 100) {
      this.transmissionLog.removeChild(this.transmissionLog.firstChild!)
    }
    
    console.log(`[${type.toUpperCase()}] ${message}`)
  }

  public clearTransmissionLog(): void {
    this.transmissionLog.innerHTML = `
      <div class="log-entry log-info">
        <span style="color: #666;">[Ready]</span> Ready to connect to ESP32...
      </div>
    `
    console.log('Transmission log cleared')
  }

  public isESP32Connected(): boolean {
    return this.isConnected
  }

  public getConnectionStatus(): TransmissionConfig {
    return { ...this.config }
  }
}