export interface PlotterPoint {
  x: number
  y: number
}

export interface PlotterAnnotation {
  type: 'pen' | 'ruler'
  points: PlotterPoint[]
  color: string
  size: number
  id: string
}

export interface RulerMeasurement {
  distance: number
  timeEstimate: number
  frequency: number
}

export class SignalPlotter {
  private canvas: HTMLCanvasElement
  private ctx: CanvasRenderingContext2D
  private importBtn: HTMLButtonElement
  private importInput: HTMLInputElement
  private zoomInBtn: HTMLButtonElement
  private zoomOutBtn: HTMLButtonElement
  private penToolBtn: HTMLButtonElement
  private rulerToolBtn: HTMLButtonElement
  private clearBtn: HTMLButtonElement
  private penColorInput: HTMLInputElement
  private penSizeInput: HTMLInputElement
  private penSizeValue: HTMLSpanElement
  private zoomLevelSpan: HTMLSpanElement
  private rulerDistanceSpan: HTMLSpanElement
  private rulerTimeSpan: HTMLSpanElement
  private rulerFrequencySpan: HTMLSpanElement
  private crosshair: HTMLElement

  private currentTool: 'none' | 'pen' | 'ruler' = 'none'
  private zoomLevel: number = 1
  private panOffset: PlotterPoint = { x: 0, y: 0 }
  private annotations: PlotterAnnotation[] = []
  private currentAnnotation: PlotterAnnotation | null = null
  private isDrawing: boolean = false
  private rulerStart: PlotterPoint | null = null
  private importedImage: HTMLImageElement | null = null
  private imageScale: number = 1
  private imageOffset: PlotterPoint = { x: 0, y: 0 }

  constructor() {
    this.initializeElements()
    this.setupCanvas()
    this.setupEventListeners()
    this.updateUI()
  }

  private initializeElements(): void {
    this.canvas = document.getElementById('plotter-canvas') as HTMLCanvasElement
    this.ctx = this.canvas.getContext('2d')!
    this.importBtn = document.getElementById('import-btn') as HTMLButtonElement
    this.importInput = document.getElementById('import-image') as HTMLInputElement
    this.zoomInBtn = document.getElementById('zoom-in-btn') as HTMLButtonElement
    this.zoomOutBtn = document.getElementById('zoom-out-btn') as HTMLButtonElement
    this.penToolBtn = document.getElementById('pen-tool-btn') as HTMLButtonElement
    this.rulerToolBtn = document.getElementById('ruler-tool-btn') as HTMLButtonElement
    this.clearBtn = document.getElementById('clear-annotations-btn') as HTMLButtonElement
    this.penColorInput = document.getElementById('pen-color') as HTMLInputElement
    this.penSizeInput = document.getElementById('pen-size') as HTMLInputElement
    this.penSizeValue = document.getElementById('pen-size-value') as HTMLSpanElement
    this.zoomLevelSpan = document.getElementById('zoom-level') as HTMLSpanElement
    this.rulerDistanceSpan = document.getElementById('ruler-distance') as HTMLSpanElement
    this.rulerTimeSpan = document.getElementById('ruler-time') as HTMLSpanElement
    this.rulerFrequencySpan = document.getElementById('ruler-frequency') as HTMLSpanElement
    this.crosshair = document.getElementById('crosshair') as HTMLElement
  }

  private setupCanvas(): void {
    const container = this.canvas.parentElement!
    const rect = container.getBoundingClientRect()
    const dpr = window.devicePixelRatio || 1
    
    this.canvas.width = rect.width * dpr
    this.canvas.height = rect.height * dpr
    
    this.ctx.scale(dpr, dpr)
    this.canvas.style.width = rect.width + 'px'
    this.canvas.style.height = rect.height + 'px'

    this.ctx.lineCap = 'round'
    this.ctx.lineJoin = 'round'
    
    this.drawGrid()
  }

  private setupEventListeners(): void {
    // Tool buttons
    if (this.importBtn && this.importInput) {
      this.importBtn.addEventListener('click', () => this.importInput.click())
    }
    if (this.importInput) {
      this.importInput.addEventListener('change', (e) => this.handleImageImport(e))
    }
    if (this.zoomInBtn) {
      this.zoomInBtn.addEventListener('click', () => this.zoomIn())
    }
    if (this.zoomOutBtn) {
      this.zoomOutBtn.addEventListener('click', () => this.zoomOut())
    }
    if (this.penToolBtn) {
      this.penToolBtn.addEventListener('click', () => this.selectTool('pen'))
    }
    if (this.rulerToolBtn) {
      this.rulerToolBtn.addEventListener('click', () => this.selectTool('ruler'))
    }
    if (this.clearBtn) {
      this.clearBtn.addEventListener('click', () => this.clearAnnotations())
    }

    // Tool controls
    if (this.penSizeInput && this.penSizeValue) {
      this.penSizeInput.addEventListener('input', () => {
        this.penSizeValue.textContent = this.penSizeInput.value + 'px'
      })
    }

    // Canvas events
    if (this.canvas) {
      this.canvas.addEventListener('mousedown', (e) => this.handleMouseDown(e))
      this.canvas.addEventListener('mousemove', (e) => this.handleMouseMove(e))
      this.canvas.addEventListener('mouseup', (e) => this.handleMouseUp(e))
      this.canvas.addEventListener('mouseleave', () => this.handleMouseLeave())
      this.canvas.addEventListener('wheel', (e) => this.handleWheel(e))
    }

    // Window resize
    window.addEventListener('resize', () => {
      setTimeout(() => this.setupCanvas(), 100)
    })
  }

  private handleImageImport(event: Event): void {
    const input = event.target as HTMLInputElement
    const file = input.files?.[0]
    
    if (!file) {
      alert('Please select a file')
      return
    }

    const reader = new FileReader()
    reader.onload = (e) => {
      const img = new Image()
      img.onload = () => {
        this.importedImage = img
        
        // Reset zoom and scale for new image
        this.zoomLevel = 1
        this.imageScale = Math.min(
          this.canvas.width / (window.devicePixelRatio || 1) / img.width,
          this.canvas.height / (window.devicePixelRatio || 1) / img.height
        ) * 0.8
        
        // Center the image
        this.imageOffset = {
          x: (this.canvas.width / (window.devicePixelRatio || 1) - img.width * this.imageScale) / 2,
          y: (this.canvas.height / (window.devicePixelRatio || 1) - img.height * this.imageScale) / 2
        }
        
        // Reset pan offset
        this.panOffset = { x: 0, y: 0 }
        
        this.redraw()
        this.updateUI()
        console.log('Image imported successfully')
      }
      img.src = e.target?.result as string
    }
    reader.readAsDataURL(file)
  }

  private selectTool(tool: 'pen' | 'ruler'): void {
    this.currentTool = this.currentTool === tool ? 'none' : tool
    this.updateUI()
    console.log('Tool selected:', this.currentTool)
  }

  private updateUI(): void {
    // Update tool buttons
    this.penToolBtn.classList.toggle('active', this.currentTool === 'pen')
    this.rulerToolBtn.classList.toggle('active', this.currentTool === 'ruler')
    
    // Update canvas cursor
    this.canvas.className = 'plotter-canvas'
    if (this.currentTool === 'pen') {
      this.canvas.classList.add('pen-mode')
    } else if (this.currentTool === 'ruler') {
      this.canvas.classList.add('ruler-mode')
    }
    
    // Update zoom level display
    this.zoomLevelSpan.textContent = Math.round(this.zoomLevel * 100) + '%'
  }

  private zoomIn(): void {
    this.zoomLevel = Math.min(this.zoomLevel * 1.2, 5)
    this.imageScale *= 1.2
    this.redraw()
    this.updateUI()
    console.log('Zoomed in to', Math.round(this.zoomLevel * 100) + '%')
  }

  private zoomOut(): void {
    this.zoomLevel = Math.max(this.zoomLevel / 1.2, 0.1)
    this.imageScale /= 1.2
    this.redraw()
    this.updateUI()
    console.log('Zoomed out to', Math.round(this.zoomLevel * 100) + '%')
  }

  private clearAnnotations(): void {
    this.annotations = []
    this.currentAnnotation = null
    this.rulerStart = null
    this.redraw()
    this.updateMeasurements({ distance: 0, timeEstimate: 0, frequency: 0 })
    console.log('Annotations cleared')
  }

  private getMousePos(event: MouseEvent): PlotterPoint {
    const rect = this.canvas.getBoundingClientRect()
    const x = (event.clientX - rect.left - this.panOffset.x) / this.zoomLevel
    const y = (event.clientY - rect.top - this.panOffset.y) / this.zoomLevel
    
    // Adjust coordinates relative to the imported image if it exists
    if (this.importedImage) {
      return {
        x: (x - this.imageOffset.x) / this.imageScale,
        y: (y - this.imageOffset.y) / this.imageScale
      }
    }
    
    return {
      x: x,
      y: y
    }
  }

  private handleMouseDown(event: MouseEvent): void {
    const pos = this.getMousePos(event)
    
    if (this.currentTool === 'pen') {
      this.startPenDrawing(pos)
    } else if (this.currentTool === 'ruler') {
      this.startRulerMeasurement(pos)
    }
  }

  private handleMouseMove(event: MouseEvent): void {
    const pos = this.getMousePos(event)
    
    // Update crosshair position
    this.crosshair.style.left = event.clientX - this.canvas.getBoundingClientRect().left + 'px'
    this.crosshair.style.top = event.clientY - this.canvas.getBoundingClientRect().top + 'px'
    this.crosshair.classList.add('visible')
    
    if (this.currentTool === 'pen' && this.isDrawing) {
      this.continuePenDrawing(pos)
    } else if (this.currentTool === 'ruler' && this.rulerStart) {
      this.updateRulerMeasurement(pos)
    }
  }

  private handleMouseUp(event: MouseEvent): void {
    if (this.currentTool === 'pen' && this.isDrawing) {
      this.finishPenDrawing()
    } else if (this.currentTool === 'ruler' && this.rulerStart) {
      const pos = this.getMousePos(event)
      this.finishRulerMeasurement(pos)
    }
  }

  private handleMouseLeave(): void {
    this.crosshair.classList.remove('visible')
    if (this.isDrawing) {
      this.finishPenDrawing()
    }
  }

  private handleWheel(event: WheelEvent): void {
    event.preventDefault()
    
    // Get mouse position for zoom center
    const rect = this.canvas.getBoundingClientRect()
    const mouseX = event.clientX - rect.left
    const mouseY = event.clientY - rect.top
    
    // Store old zoom level
    const oldZoom = this.zoomLevel
    const oldImageScale = this.imageScale
    
    if (event.deltaY < 0) {
      this.zoomIn()
    } else {
      this.zoomOut()
    }
    
    // Adjust pan offset to zoom towards mouse position
    if (this.importedImage) {
      const zoomRatio = this.zoomLevel / oldZoom
      const imageScaleRatio = this.imageScale / oldImageScale
      
      this.panOffset.x = mouseX - (mouseX - this.panOffset.x) * zoomRatio
      this.panOffset.y = mouseY - (mouseY - this.panOffset.y) * zoomRatio
      
      // Adjust image offset for proper zoom centering
      this.imageOffset.x = this.imageOffset.x * imageScaleRatio
      this.imageOffset.y = this.imageOffset.y * imageScaleRatio
      
      this.redraw()
    }
  }

  private startPenDrawing(pos: PlotterPoint): void {
    this.isDrawing = true
    this.currentAnnotation = {
      type: 'pen',
      points: [pos],
      color: this.penColorInput.value,
      size: parseInt(this.penSizeInput.value),
      id: Date.now().toString()
    }
  }

  private continuePenDrawing(pos: PlotterPoint): void {
    if (this.currentAnnotation && this.isDrawing) {
      this.currentAnnotation.points.push(pos)
      this.redraw()
    }
  }

  private finishPenDrawing(): void {
    if (this.currentAnnotation && this.isDrawing) {
      this.annotations.push(this.currentAnnotation)
      this.currentAnnotation = null
    }
    this.isDrawing = false
  }

  private startRulerMeasurement(pos: PlotterPoint): void {
    this.rulerStart = pos
  }

  private updateRulerMeasurement(pos: PlotterPoint): void {
    if (this.rulerStart) {
      const distance = Math.sqrt(
        Math.pow(pos.x - this.rulerStart.x, 2) + 
        Math.pow(pos.y - this.rulerStart.y, 2)
      )
      
      // Scale distance based on zoom and image scale for accurate measurements
      const scaledDistance = this.importedImage ? 
        distance * this.imageScale * this.zoomLevel : 
        distance * this.zoomLevel
      
      // Estimate time and frequency based on scaled pixel distance
      const timeEstimate = scaledDistance * 0.1 // 0.1ms per scaled pixel
      const frequency = timeEstimate > 0 ? 1000 / timeEstimate : 0
      
      this.updateMeasurements({
        distance: Math.round(scaledDistance),
        timeEstimate: Math.round(timeEstimate * 100) / 100,
        frequency: Math.round(frequency * 10) / 10
      })
      
      this.redraw()
      this.drawTemporaryRuler(this.rulerStart, pos)
    }
  }

  private finishRulerMeasurement(pos: PlotterPoint): void {
    if (this.rulerStart) {
      const rulerAnnotation: PlotterAnnotation = {
        type: 'ruler',
        points: [this.rulerStart, pos],
        color: '#0066ff',
        size: 2,
        id: Date.now().toString()
      }
      this.annotations.push(rulerAnnotation)
      this.rulerStart = null
      this.redraw()
    }
  }

  private updateMeasurements(measurement: RulerMeasurement): void {
    this.rulerDistanceSpan.textContent = measurement.distance + ' px'
    this.rulerTimeSpan.textContent = measurement.timeEstimate + ' ms'
    this.rulerFrequencySpan.textContent = measurement.frequency + ' Hz'
  }

  private drawGrid(): void {
    const width = this.canvas.width / (window.devicePixelRatio || 1)
    const height = this.canvas.height / (window.devicePixelRatio || 1)
    
    this.ctx.strokeStyle = '#333'
    this.ctx.lineWidth = 0.5
    
    const gridSize = 20 * this.zoomLevel
    
    // Vertical lines
    for (let x = 0; x <= width; x += gridSize) {
      this.ctx.beginPath()
      this.ctx.moveTo(x, 0)
      this.ctx.lineTo(x, height)
      this.ctx.stroke()
    }
    
    // Horizontal lines
    for (let y = 0; y <= height; y += gridSize) {
      this.ctx.beginPath()
      this.ctx.moveTo(0, y)
      this.ctx.lineTo(width, y)
      this.ctx.stroke()
    }
  }

  private redraw(): void {
    const width = this.canvas.width / (window.devicePixelRatio || 1)
    const height = this.canvas.height / (window.devicePixelRatio || 1)
    
    // Clear canvas
    this.ctx.fillStyle = '#1a1a1a'
    this.ctx.fillRect(0, 0, width, height)
    
    // Draw grid
    this.drawGrid()
    
    // Draw imported image
    if (this.importedImage) {
      this.ctx.save()
      
      // Apply zoom and pan transformations
      this.ctx.translate(this.panOffset.x * this.zoomLevel, this.panOffset.y * this.zoomLevel)
      this.ctx.scale(this.zoomLevel, this.zoomLevel)
      
      this.ctx.drawImage(
        this.importedImage,
        this.imageOffset.x,
        this.imageOffset.y,
        this.importedImage.width * this.imageScale,
        this.importedImage.height * this.imageScale
      )
      this.ctx.restore()
    }
    
    // Draw annotations
    this.drawAnnotations()
    
    // Draw current annotation
    if (this.currentAnnotation) {
      this.drawAnnotation(this.currentAnnotation)
    }
  }

  private drawAnnotations(): void {
    this.annotations.forEach(annotation => {
      this.drawAnnotation(annotation)
    })
  }

  private drawAnnotation(annotation: PlotterAnnotation): void {
    if (annotation.points.length === 0) return
    
    this.ctx.save()
    
    // Apply transformations in correct order for image coordinates
    this.ctx.translate(this.panOffset.x, this.panOffset.y)
    this.ctx.scale(this.zoomLevel, this.zoomLevel)
    
    // If we have an imported image, transform coordinates to image space
    if (this.importedImage) {
      this.ctx.translate(this.imageOffset.x, this.imageOffset.y)
      this.ctx.scale(this.imageScale, this.imageScale)
    }
    
    this.ctx.strokeStyle = annotation.color
    this.ctx.lineWidth = annotation.size / this.zoomLevel // Scale line width
    
    if (annotation.type === 'pen') {
      this.ctx.beginPath()
      this.ctx.moveTo(annotation.points[0].x, annotation.points[0].y)
      
      for (let i = 1; i < annotation.points.length; i++) {
        this.ctx.lineTo(annotation.points[i].x, annotation.points[i].y)
      }
      
      this.ctx.stroke()
    } else if (annotation.type === 'ruler' && annotation.points.length >= 2) {
      const start = annotation.points[0]
      const end = annotation.points[1]
      
      // Draw ruler line
      this.ctx.beginPath()
      this.ctx.moveTo(start.x, start.y)
      this.ctx.lineTo(end.x, end.y)
      this.ctx.stroke()
      
      // Draw measurement markers
      this.ctx.fillStyle = annotation.color
      this.ctx.beginPath()
      this.ctx.arc(start.x, start.y, 4 / this.zoomLevel, 0, 2 * Math.PI)
      this.ctx.fill()
      
      this.ctx.beginPath()
      this.ctx.arc(end.x, end.y, 4 / this.zoomLevel, 0, 2 * Math.PI)
      this.ctx.fill()
    }
    
    this.ctx.restore()
  }

  private drawTemporaryRuler(start: PlotterPoint, end: PlotterPoint): void {
    this.ctx.save()
    
    // Apply transformations
    this.ctx.translate(this.panOffset.x, this.panOffset.y)
    this.ctx.scale(this.zoomLevel, this.zoomLevel)
    
    this.ctx.strokeStyle = '#00ff41'
    this.ctx.lineWidth = 2 / this.zoomLevel
    this.ctx.setLineDash([5, 5])
    
    this.ctx.beginPath()
    this.ctx.moveTo(start.x, start.y)
    this.ctx.lineTo(end.x, end.y)
    this.ctx.stroke()
    
    this.ctx.setLineDash([])
    this.ctx.restore()
  }

  public exportAnnotations(): string {
    return JSON.stringify({
      annotations: this.annotations,
      zoomLevel: this.zoomLevel,
      panOffset: this.panOffset
    })
  }

  public importAnnotations(data: string): void {
    try {
      const parsed = JSON.parse(data)
      this.annotations = parsed.annotations || []
      this.zoomLevel = parsed.zoomLevel || 1
      this.panOffset = parsed.panOffset || { x: 0, y: 0 }
      this.redraw()
      this.updateUI()
      console.log('Annotations imported successfully')
    } catch (error) {
      console.error('Error importing annotations:', error)
    }
  }
}