import { SignalGenerator } from './signal-generator'
import { CanvasRenderer } from './canvas-renderer'

export class UIController {
  private signalGenerator: SignalGenerator
  private canvasRenderer: CanvasRenderer
  
  // UI Elements
  private rpmSlider: HTMLInputElement
  private rpmValue: HTMLSpanElement
  private teethSelect: HTMLSelectElement
  private camRatioSelect: HTMLSelectElement
  private startBtn: HTMLButtonElement
  private stopBtn: HTMLButtonElement
  private resetBtn: HTMLButtonElement
  private statusSpan: HTMLSpanElement
  private runtimeSpan: HTMLSpanElement
  private pulseCountSpan: HTMLSpanElement
  private crankFreqSpan: HTMLSpanElement
  private cam1FreqSpan: HTMLSpanElement
  private cam2FreqSpan: HTMLSpanElement

  private runtimeInterval: number | null = null

  constructor(signalGenerator: SignalGenerator, canvasRenderer: CanvasRenderer) {
    this.signalGenerator = signalGenerator
    this.canvasRenderer = canvasRenderer
    
    this.initializeElements()
  }

  private initializeElements(): void {
    this.rpmSlider = document.getElementById('rpm') as HTMLInputElement
    this.rpmValue = document.getElementById('rpm-value') as HTMLSpanElement
    this.teethSelect = document.getElementById('teeth') as HTMLSelectElement
    this.camRatioSelect = document.getElementById('cam-ratio') as HTMLSelectElement
    this.startBtn = document.getElementById('start-btn') as HTMLButtonElement
    this.stopBtn = document.getElementById('stop-btn') as HTMLButtonElement
    this.resetBtn = document.getElementById('reset-btn') as HTMLButtonElement
    this.statusSpan = document.getElementById('status') as HTMLSpanElement
    this.runtimeSpan = document.getElementById('runtime') as HTMLSpanElement
    this.pulseCountSpan = document.getElementById('pulse-count') as HTMLSpanElement
    this.crankFreqSpan = document.getElementById('crank-freq') as HTMLSpanElement
    this.cam1FreqSpan = document.getElementById('cam1-freq') as HTMLSpanElement
    this.cam2FreqSpan = document.getElementById('cam2-freq') as HTMLSpanElement
  }

  public init(): void {
    this.setupEventListeners()
    this.updateUI()
    this.updateFrequencyDisplays()
    
    // Set up signal generation callback
    this.signalGenerator.onSignalUpdate((data) => {
      this.canvasRenderer.renderSignals(data)
      this.updatePulseCount()
    })
  }

  private setupEventListeners(): void {
    // RPM slider
    if (this.rpmSlider) {
      this.rpmSlider.addEventListener('input', () => {
        const rpm = parseInt(this.rpmSlider.value)
        this.rpmValue.textContent = rpm.toString()
        this.signalGenerator.setConfig({ rpm })
        this.updateFrequencyDisplays()
      })
    }

    // Teeth count selector
    if (this.teethSelect) {
      this.teethSelect.addEventListener('change', () => {
        const teethCount = parseInt(this.teethSelect.value)
        this.signalGenerator.setConfig({ teethCount })
        this.updateFrequencyDisplays()
      })
    }

    // Cam ratio selector
    if (this.camRatioSelect) {
      this.camRatioSelect.addEventListener('change', () => {
        const camRatio = parseInt(this.camRatioSelect.value)
        this.signalGenerator.setConfig({ camRatio })
        this.updateFrequencyDisplays()
      })
    }

    // Control buttons
    if (this.startBtn) {
      this.startBtn.addEventListener('click', () => this.startGeneration())
    }
    if (this.stopBtn) {
      this.stopBtn.addEventListener('click', () => this.stopGeneration())
    }
    if (this.resetBtn) {
      this.resetBtn.addEventListener('click', () => this.resetGeneration())
    }

    // Handle window resize
    window.addEventListener('resize', () => {
      setTimeout(() => {
        this.canvasRenderer = new CanvasRenderer()
      }, 100)
    })
  }

  private startGeneration(): void {
    this.signalGenerator.start()
    this.updateUI()
    this.startRuntimeTimer()
  }

  private stopGeneration(): void {
    this.signalGenerator.stop()
    this.updateUI()
    this.stopRuntimeTimer()
  }

  private resetGeneration(): void {
    this.signalGenerator.reset()
    this.canvasRenderer.clearAll()
    this.updateUI()
    this.stopRuntimeTimer()
    this.updateRuntimeDisplay()
    this.updatePulseCount()
  }

  private updateUI(): void {
    const isRunning = this.signalGenerator.isGenerating()
    
    if (this.startBtn) {
      this.startBtn.disabled = isRunning
    }
    if (this.stopBtn) {
      this.stopBtn.disabled = !isRunning
    }
    if (this.statusSpan) {
      this.statusSpan.textContent = isRunning ? 'Running' : 'Stopped'
      this.statusSpan.style.color = isRunning ? '#10b981' : '#64748b'
    }
    
    // Disable controls while running
    if (this.rpmSlider) {
      this.rpmSlider.disabled = isRunning
    }
    if (this.teethSelect) {
      this.teethSelect.disabled = isRunning
    }
    if (this.camRatioSelect) {
      this.camRatioSelect.disabled = isRunning
    }
  }

  private updateFrequencyDisplays(): void {
    const crankFreq = this.signalGenerator.getCrankFrequency()
    const camFreq = this.signalGenerator.getCamFrequency()
    
    if (this.crankFreqSpan) {
      this.crankFreqSpan.textContent = `Frequency: ${crankFreq.toFixed(1)} Hz`
    }
    if (this.cam1FreqSpan) {
      this.cam1FreqSpan.textContent = `Frequency: ${camFreq.toFixed(1)} Hz`
    }
    if (this.cam2FreqSpan) {
      this.cam2FreqSpan.textContent = `Frequency: ${camFreq.toFixed(1)} Hz`
    }
  }

  private startRuntimeTimer(): void {
    this.runtimeInterval = window.setInterval(() => {
      this.updateRuntimeDisplay()
    }, 100)
  }

  private stopRuntimeTimer(): void {
    if (this.runtimeInterval) {
      clearInterval(this.runtimeInterval)
      this.runtimeInterval = null
    }
  }

  private updateRuntimeDisplay(): void {
    const runtime = this.signalGenerator.getRuntime()
    const seconds = Math.floor(runtime / 1000)
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = seconds % 60
    
    if (this.runtimeSpan) {
      this.runtimeSpan.textContent = 
        `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`
    }
  }

  private updatePulseCount(): void {
    if (this.pulseCountSpan) {
      this.pulseCountSpan.textContent = this.signalGenerator.getPulseCount().toString()
    }
  }
}