export interface SignalConfig {
  rpm: number
  teethCount: number
  camRatio: number
  signalType: 'square' | 'sine'
}

export interface SignalData {
  crank: number[]
  cam1: number[]
  cam2: number[]
  timestamp: number
}

export class SignalGenerator {
  private config: SignalConfig = {
    rpm: 500,
    teethCount: 36,
    camRatio: 2,
    signalType: 'square'
  }
  
  private isRunning = false
  private startTime = 0
  private pulseCount = 0
  private animationId: number | null = null
  private callbacks: ((data: SignalData) => void)[] = []
  private timeWindow: number = 200 // Default time window in ms

  constructor() {}

  public setConfig(config: Partial<SignalConfig>): void {
    this.config = { ...this.config, ...config }
  }

  public getConfig(): SignalConfig {
    return { ...this.config }
  }

  public start(): void {
    if (this.isRunning) return
    
    this.isRunning = true
    this.startTime = Date.now()
    this.pulseCount = 0
    this.generateSignals()
  }

  public stop(): void {
    this.isRunning = false
    if (this.animationId) {
      cancelAnimationFrame(this.animationId)
      this.animationId = null
    }
  }

  public reset(): void {
    this.stop()
    this.pulseCount = 0
    this.startTime = 0
  }

  public isGenerating(): boolean {
    return this.isRunning
  }

  public getRuntime(): number {
    if (!this.startTime) return 0
    return Date.now() - this.startTime
  }

  public getPulseCount(): number {
    return this.pulseCount
  }

  public onSignalUpdate(callback: (data: SignalData) => void): void {
    this.callbacks.push(callback)
  }

  private generateSignals(): void {
    if (!this.isRunning) return

    const currentTime = Date.now()
    const runtime = currentTime - this.startTime
    
    // Calculate frequencies
    const crankFreq = (this.config.rpm / 60) * (this.config.teethCount - 1) // Account for missing tooth
    const camFreq = crankFreq / this.config.camRatio

    // Generate signal data
    const signalData: SignalData = {
      crank: this.generateCrankSignal(runtime, crankFreq),
      cam1: this.generateCamSignal(runtime, camFreq, 0), // No phase offset
      cam2: this.generateCamSignal(runtime, camFreq, Math.PI), // 180° phase offset
      timestamp: currentTime
    }

    // Update pulse count
    this.pulseCount += signalData.crank.filter(v => v > 0.5).length

    // Notify callbacks
    this.callbacks.forEach(callback => callback(signalData))

    // Schedule next frame
    this.animationId = requestAnimationFrame(() => this.generateSignals())
  }

  private generateCrankSignal(time: number, frequency: number): number[] {
    const samples = 1600 // Increased canvas width for more pulses
    const signal: number[] = []
    const timeWindow = this.timeWindow // Use configurable time window
    
    for (let i = 0; i < samples; i++) {
      const t = (time + (i / samples) * timeWindow) / 1000 // Convert to seconds
      const toothPosition = (t * frequency) % (this.config.teethCount - 1)
      
      // Create missing tooth pattern (36-1, 60-2, etc.)
      let amplitude = 0
      if (this.config.teethCount === 36) {
        // 36-1 pattern: missing tooth at position 35
        amplitude = (toothPosition >= 34.5 && toothPosition < 35.5) ? 0 : 
                   this.generateWaveform(t, frequency)
      } else if (this.config.teethCount === 60) {
        // 60-2 pattern: missing teeth at positions 58-59
        amplitude = (toothPosition >= 57.5 && toothPosition < 59.5) ? 0 : 
                   this.generateWaveform(t, frequency)
      } else {
        // 24-1 pattern: missing tooth at position 23
        amplitude = (toothPosition >= 22.5 && toothPosition < 23.5) ? 0 : 
                   this.generateWaveform(t, frequency)
      }
      
      signal.push(amplitude)
    }
    
    return signal
  }

  private generateCamSignal(time: number, frequency: number, phaseOffset: number): number[] {
    const samples = 1600
    const signal: number[] = []
    const timeWindow = this.timeWindow // Use configurable time window
    
    for (let i = 0; i < samples; i++) {
      const t = (time + (i / samples) * timeWindow) / 1000
      
      // Cam signal is typically one pulse per cam revolution
      const camPhase = (2 * Math.PI * t * frequency) + phaseOffset
      const pulseWidth = Math.PI / 4 // Narrow pulse
      
      let amplitude = 0
      if (this.config.signalType === 'square') {
        amplitude = (camPhase % (2 * Math.PI)) < pulseWidth ? 1 : 0
      } else {
        // Sine wave with pulse gating
        const sineValue = (Math.sin(camPhase) + 1) / 2 // Normalize to 0-1
        amplitude = (camPhase % (2 * Math.PI)) < pulseWidth ? sineValue : 0
      }
      
      signal.push(amplitude)
    }
    
    return signal
  }

  private generateWaveform(t: number, frequency: number): number {
    if (this.config.signalType === 'square') {
      return Math.sin(2 * Math.PI * t * frequency) > 0 ? 1 : 0
    } else {
      // Sine wave normalized to 0-1 range
      return (Math.sin(2 * Math.PI * t * frequency) + 1) / 2
    }
  }
  public getCrankFrequency(): number {
    return (this.config.rpm / 60) * (this.config.teethCount - 1)
  }

  public getCamFrequency(): number {
    return this.getCrankFrequency() / this.config.camRatio
  }

  public setTimeWindow(timeWindow: number): void {
    this.timeWindow = timeWindow
  }
}