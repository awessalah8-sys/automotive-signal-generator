export interface VehicleBrand {
  name: string
  models: string[]
}

export class VehicleData {
  private brands: VehicleBrand[] = [
    // Asian Brands
    {
      name: "Toyota",
      models: ["Camry", "Corolla", "RAV4", "Highlander", "Prius", "Sienna", "Tacoma", "Tundra", "4Runner", "Sequoia", "Land Cruiser", "Avalon", "Yaris", "C-HR", "Venza", "Supra", "86", "Mirai"]
    },
    {
      name: "Honda",
      models: ["Civic", "Accord", "CR-V", "Pilot", "Odyssey", "HR-V", "Passport", "Ridgeline", "Fit", "Insight", "Clarity", "CR-V Hybrid", "Accord Hybrid"]
    },
    {
      name: "Nissan",
      models: ["Altima", "Sentra", "Rogue", "Pathfinder", "Murano", "Armada", "Titan", "Frontier", "370Z", "GT-R", "Leaf", "Kicks", "Versa", "Maxima", "NV200", "Sunny", "Navara"]
    },
    {
      name: "Mazda",
      models: ["Mazda3", "Mazda6", "CX-3", "CX-5", "CX-9", "CX-30", "MX-5 Miata", "CX-50"]
    },
    {
      name: "Subaru",
      models: ["Outback", "Forester", "Impreza", "Legacy", "Crosstrek", "Ascent", "WRX", "BRZ"]
    },
    {
      name: "Mitsubishi",
      models: ["Outlander", "Eclipse Cross", "Mirage", "Outlander Sport", "Outlander PHEV"]
    },
    {
      name: "Acura",
      models: ["TLX", "ILX", "RDX", "MDX", "NSX", "Integra"]
    },
    {
      name: "Infiniti",
      models: ["Q50", "Q60", "QX50", "QX60", "QX80", "Q70"]
    },
    {
      name: "Lexus",
      models: ["ES", "IS", "GS", "LS", "NX", "RX", "GX", "LX", "UX", "LC", "RC", "LFA"]
    },
    {
      name: "Hyundai",
      models: ["Elantra", "Sonata", "Tucson", "Santa Fe", "Palisade", "Kona", "Venue", "Veloster", "Genesis", "Ioniq", "Nexo"]
    },
    {
      name: "Kia",
      models: ["Forte", "Optima", "Sportage", "Sorento", "Telluride", "Soul", "Rio", "Stinger", "Niro", "Seltos", "K5", "Carnival"]
    },
    {
      name: "Genesis",
      models: ["G70", "G80", "G90", "GV70", "GV80"]
    },

    // American Brands
    {
      name: "Ford",
      models: ["F-150", "Mustang", "Explorer", "Escape", "Edge", "Expedition", "Ranger", "Bronco", "Maverick", "Transit", "E-Series", "Focus", "Fusion", "Fiesta", "Taurus", "Flex", "EcoSport", "Bronco Sport"]
    },
    {
      name: "Chevrolet",
      models: ["Silverado", "Equinox", "Malibu", "Traverse", "Tahoe", "Suburban", "Camaro", "Corvette", "Colorado", "Blazer", "Trax", "Spark", "Sonic", "Cruze", "Impala", "Volt", "Bolt"]
    },
    {
      name: "GMC",
      models: ["Sierra", "Acadia", "Terrain", "Yukon", "Canyon", "Savana", "Hummer EV"]
    },
    {
      name: "Ram",
      models: ["1500", "2500", "3500", "ProMaster", "ProMaster City"]
    },
    {
      name: "Jeep",
      models: ["Wrangler", "Grand Cherokee", "Cherokee", "Compass", "Renegade", "Gladiator", "Grand Wagoneer", "Wagoneer"]
    },
    {
      name: "Dodge",
      models: ["Charger", "Challenger", "Durango", "Journey", "Grand Caravan"]
    },
    {
      name: "Chrysler",
      models: ["300", "Pacifica", "Voyager"]
    },
    {
      name: "Cadillac",
      models: ["Escalade", "XT4", "XT5", "XT6", "CT4", "CT5", "Lyriq"]
    },
    {
      name: "Lincoln",
      models: ["Navigator", "Aviator", "Corsair", "Nautilus", "Continental", "MKZ", "MKC"]
    },
    {
      name: "Buick",
      models: ["Enclave", "Encore", "Envision", "Regal", "LaCrosse"]
    },
    {
      name: "Tesla",
      models: ["Model S", "Model 3", "Model X", "Model Y", "Cybertruck", "Roadster"]
    },

    // European Brands
    {
      name: "BMW",
      models: ["3 Series", "5 Series", "7 Series", "X1", "X3", "X5", "X7", "Z4", "i3", "i4", "iX", "M3", "M5", "X6", "4 Series", "8 Series", "2 Series", "1 Series"]
    },
    {
      name: "Mercedes-Benz",
      models: ["C-Class", "E-Class", "S-Class", "GLA", "GLC", "GLE", "GLS", "A-Class", "CLA", "CLS", "G-Class", "SL", "AMG GT", "EQS", "EQC", "Sprinter", "Metris"]
    },
    {
      name: "Audi",
      models: ["A3", "A4", "A6", "A8", "Q3", "Q5", "Q7", "Q8", "TT", "R8", "e-tron GT", "A5", "A7", "RS3", "RS4", "RS6", "RS7"]
    },
    {
      name: "Volkswagen",
      models: ["Jetta", "Passat", "Tiguan", "Atlas", "Golf", "Beetle", "Arteon", "ID.4", "Touareg", "Golf R", "GTI"]
    },
    {
      name: "Porsche",
      models: ["911", "Cayenne", "Macan", "Panamera", "Taycan", "718 Boxster", "718 Cayman"]
    },
    {
      name: "Volvo",
      models: ["XC40", "XC60", "XC90", "S60", "S90", "V60", "V90", "C40", "Polestar"]
    },
    {
      name: "Jaguar",
      models: ["XE", "XF", "XJ", "F-PACE", "E-PACE", "I-PACE", "F-TYPE"]
    },
    {
      name: "Land Rover",
      models: ["Range Rover", "Range Rover Sport", "Range Rover Evoque", "Range Rover Velar", "Discovery", "Discovery Sport", "Defender"]
    },
    {
      name: "Mini",
      models: ["Cooper", "Countryman", "Clubman", "Convertible", "Hardtop"]
    },
    {
      name: "Fiat",
      models: ["500", "500X", "500L", "124 Spider"]
    },
    {
      name: "Alfa Romeo",
      models: ["Giulia", "Stelvio", "4C"]
    },
    {
      name: "Maserati",
      models: ["Ghibli", "Quattroporte", "Levante", "GranTurismo", "MC20"]
    },
    {
      name: "Ferrari",
      models: ["488", "F8", "SF90", "Roma", "Portofino", "812", "LaFerrari"]
    },
    {
      name: "Lamborghini",
      models: ["Huracán", "Aventador", "Urus"]
    },
    {
      name: "Bentley",
      models: ["Continental", "Flying Spur", "Bentayga", "Mulsanne"]
    },
    {
      name: "Rolls-Royce",
      models: ["Ghost", "Phantom", "Wraith", "Dawn", "Cullinan"]
    },

    // Chinese Brands
    {
      name: "BYD",
      models: ["Tang", "Song", "Qin", "Han", "Yuan", "e6", "Dolphin", "Seal"]
    },
    {
      name: "Geely",
      models: ["Emgrand", "Vision", "GC9", "Atlas", "Coolray", "Azkarra"]
    },
    {
      name: "Great Wall",
      models: ["Haval H6", "Haval H9", "Wingle", "Pao", "Tank 300"]
    },
    {
      name: "Chery",
      models: ["Tiggo", "Arrizo", "QQ", "eQ1", "Omoda"]
    },
    {
      name: "NIO",
      models: ["ES8", "ES6", "EC6", "ET7", "ET5"]
    },
    {
      name: "Xpeng",
      models: ["P7", "G3", "P5", "G9"]
    },
    {
      name: "Li Auto",
      models: ["Li ONE", "L9", "L8", "L7"]
    },
    {
      name: "MG",
      models: ["ZS", "HS", "5", "6", "Marvel R"]
    }
  ]

  private years: number[] = []
  private engineSizes: string[] = [
    "1.0L", "1.2L", "1.3L", "1.4L", "1.5L", "1.6L", "1.8L", "2.0L", "2.2L", "2.3L", "2.4L", "2.5L", 
    "2.7L", "3.0L", "3.2L", "3.5L", "3.6L", "3.7L", "4.0L", "4.2L", "4.6L", "5.0L", "5.2L", "5.4L", 
    "5.7L", "6.0L", "6.2L", "6.4L", "6.6L", "6.8L", "7.0L", "8.0L",
    "1.0L Turbo", "1.4L Turbo", "1.5L Turbo", "1.6L Turbo", "2.0L Turbo", "2.3L Turbo", "2.7L Turbo", "3.0L Turbo",
    "1.5L Hybrid", "2.0L Hybrid", "2.5L Hybrid", "3.5L Hybrid",
    "Electric", "Plug-in Hybrid"
  ]

  constructor() {
    // Generate years from 2000 to 2026
    for (let year = 2000; year <= 2026; year++) {
      this.years.push(year)
    }
  }

  getBrands(): VehicleBrand[] {
    return this.brands
  }

  getModelsForBrand(brandName: string): string[] {
    const brand = this.brands.find(b => b.name === brandName)
    return brand ? brand.models : []
  }

  getYears(): number[] {
    return this.years
  }

  getEngineSizes(): string[] {
    return this.engineSizes
  }
}