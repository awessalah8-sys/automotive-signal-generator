import { SignalGenerator } from './signal-generator'
import { CanvasRenderer } from './canvas-renderer'
import { UIController } from './ui-controller'
import { VehicleData } from './vehicle-data'
import { SignalTransmitter } from './signal-transmitter'
import { SignalPlotter } from './signal-plotter'
import './style.css'

// Register Service Worker for PWA functionality
if ('serviceWorker' in navigator) {
  // Skip Service Worker registration in unsupported environments
  let isUnsupportedEnvironment = 
    window.location.hostname.includes('stackblitz.com') ||
    window.location.hostname.includes('webcontainer.io') ||
    (window.location.hostname.includes('localhost') && window.location.port === '5173') ||
    (window.location.hostname.includes('127.0.0.1') && window.location.port === '5173')
  
  // Check if running in iframe with StackBlitz parent
  try {
    if (window.self !== window.top && (window.parent.location.hostname.includes('stackblitz') || window.parent.location.href.includes('stackblitz'))) {
      isUnsupportedEnvironment = true
    }
  } catch (e) {
    // Cross-origin iframe access blocked, assume unsupported environment
    if (window.self !== window.top) {
      isUnsupportedEnvironment = true
    }
  }
  
  if (isUnsupportedEnvironment) {
    console.log('Service Worker registration skipped: unsupported environment')
  } else {
    window.addEventListener('load', async () => {
      try {
        const registration = await navigator.serviceWorker.register('/sw.js')
        console.log('Service Worker registered successfully:', registration.scope)
        
        // Check for updates
        registration.addEventListener('updatefound', () => {
          const newWorker = registration.installing
          if (newWorker) {
            newWorker.addEventListener('statechange', () => {
              if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                // New content is available, prompt user to refresh
                showUpdateNotification()
              }
            })
          }
        })
      } catch (error) {
        console.error('Service Worker registration failed:', error)
      }
    })
  }
}

// Show update notification
function showUpdateNotification(): void {
  const notification = document.createElement('div')
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: #2563eb;
    color: white;
    padding: 1rem 1.5rem;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    z-index: 10000;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    max-width: 300px;
  `
  
  notification.innerHTML = `
    <div style="margin-bottom: 0.5rem; font-weight: 600;">Update Available</div>
    <div style="margin-bottom: 1rem; font-size: 0.875rem;">A new version of the app is available.</div>
    <button onclick="window.location.reload()" style="
      background: white;
      color: #2563eb;
      border: none;
      padding: 0.5rem 1rem;
      border-radius: 4px;
      font-weight: 600;
      cursor: pointer;
      margin-right: 0.5rem;
    ">Update Now</button>
    <button onclick="this.parentElement.remove()" style="
      background: transparent;
      color: white;
      border: 1px solid white;
      padding: 0.5rem 1rem;
      border-radius: 4px;
      cursor: pointer;
    ">Later</button>
  `
  
  document.body.appendChild(notification)
  
  // Auto-remove after 10 seconds
  setTimeout(() => {
    if (notification.parentElement) {
      notification.remove()
    }
  }, 10000)
}

// PWA Install Prompt
let deferredPrompt: any = null

window.addEventListener('beforeinstallprompt', (e) => {
  console.log('PWA install prompt available')
  e.preventDefault()
  deferredPrompt = e
  showInstallButton()
})

function showInstallButton(): void {
  const installBtn = document.createElement('button')
  installBtn.textContent = '📱 Install App'
  installBtn.style.cssText = `
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: linear-gradient(135deg, #10b981, #059669);
    color: white;
    border: none;
    padding: 1rem 1.5rem;
    border-radius: 50px;
    font-weight: 600;
    cursor: pointer;
    box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
    z-index: 10000;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    transition: all 0.2s ease;
  `
  
  installBtn.addEventListener('mouseenter', () => {
    installBtn.style.transform = 'translateY(-2px)'
    installBtn.style.boxShadow = '0 6px 16px rgba(16, 185, 129, 0.4)'
  })
  
  installBtn.addEventListener('mouseleave', () => {
    installBtn.style.transform = 'translateY(0)'
    installBtn.style.boxShadow = '0 4px 12px rgba(16, 185, 129, 0.3)'
  })
  
  installBtn.addEventListener('click', async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt()
      const { outcome } = await deferredPrompt.userChoice
      console.log('PWA install outcome:', outcome)
      deferredPrompt = null
      installBtn.remove()
    }
  })
  
  document.body.appendChild(installBtn)
  
  // Auto-hide after 30 seconds
  setTimeout(() => {
    if (installBtn.parentElement) {
      installBtn.remove()
    }
  }, 30000)
}

// Handle app installation
window.addEventListener('appinstalled', () => {
  console.log('PWA was installed successfully')
  deferredPrompt = null
  
  // Show success message
  const successMsg = document.createElement('div')
  successMsg.style.cssText = `
    position: fixed;
    top: 20px;
    left: 50%;
    transform: translateX(-50%);
    background: #10b981;
    color: white;
    padding: 1rem 2rem;
    border-radius: 8px;
    font-weight: 600;
    z-index: 10000;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  `
  successMsg.textContent = '✅ App installed successfully!'
  document.body.appendChild(successMsg)
  
  setTimeout(() => successMsg.remove(), 3000)
})

// Global instances
let signalGenerator: SignalGenerator
let canvasRenderer: CanvasRenderer
let uiController: UIController
let vehicleData: VehicleData
let signalTransmitter: SignalTransmitter
let signalPlotter: SignalPlotter

// Signal history storage
interface SignalHistoryEntry {
  id: string
  brand: string
  model: string
  year: string
  engine: string
  timestamp: number
  signalData: {
    crank: number[]
    cam1: number[]
    cam2: number[]
  }
  config: {
    rpm: number
    signalType: string
  }
}

let signalHistory: SignalHistoryEntry[] = []

// Initialize the application
function init(): void {
  console.log('Starting application initialization...')
  
  try {
    signalGenerator = new SignalGenerator()
    console.log('SignalGenerator created')
    
    canvasRenderer = new CanvasRenderer()
    console.log('CanvasRenderer created')
    
    uiController = new UIController(signalGenerator, canvasRenderer)
    console.log('UIController created')
    
    vehicleData = new VehicleData()
    console.log('VehicleData created')
    
    signalTransmitter = new SignalTransmitter()
    console.log('SignalTransmitter created')
    
    signalPlotter = new SignalPlotter()
    console.log('SignalPlotter created')

    // Make instances globally available for debugging
    ;(window as any).signalGenerator = signalGenerator
    ;(window as any).canvasRenderer = canvasRenderer

    setupVehicleSelectors()
    setupZoomControls()
    setupSignalTypeControl()
    setupFileControls()
    setupHistoryControls()
    
    uiController.init()
    
    console.log('Automotive Signal Generator initialized successfully')
  } catch (error) {
    console.error('Error during initialization:', error)
  }
}

function setupVehicleSelectors(): void {
  console.log('Setting up vehicle selectors...')
  
  const brandSelect = document.getElementById('brand') as HTMLSelectElement
  const modelSelect = document.getElementById('model') as HTMLSelectElement
  const yearSelect = document.getElementById('year') as HTMLSelectElement
  const engineSelect = document.getElementById('engine') as HTMLSelectElement

  if (!brandSelect || !modelSelect || !yearSelect || !engineSelect) {
    console.error('Vehicle selector elements not found')
    return
  }

  // Populate brand selector
  const brands = vehicleData.getBrands()
  brands.forEach(brand => {
    const option = document.createElement('option')
    option.value = brand.name
    option.textContent = brand.name
    brandSelect.appendChild(option)
  })

  // Populate year selector
  const years = vehicleData.getYears()
  years.forEach(year => {
    const option = document.createElement('option')
    option.value = year.toString()
    option.textContent = year.toString()
    yearSelect.appendChild(option)
  })

  // Populate engine selector
  const engines = vehicleData.getEngineSizes()
  engines.forEach(engine => {
    const option = document.createElement('option')
    option.value = engine
    option.textContent = engine
    engineSelect.appendChild(option)
  })

  // Brand change handler
  if (brandSelect) {
    brandSelect.addEventListener('change', () => {
      const selectedBrand = brandSelect.value
      modelSelect.innerHTML = '<option value="">Select Model</option>'
      modelSelect.disabled = !selectedBrand

      if (selectedBrand) {
        const models = vehicleData.getModelsForBrand(selectedBrand)
        models.forEach(model => {
          const option = document.createElement('option')
          option.value = model
          option.textContent = model
          modelSelect.appendChild(option)
        })
        modelSelect.disabled = false
      }
    })
  }
  
  console.log('Vehicle selectors setup complete')
}

function setupZoomControls(): void {
  console.log('Setting up zoom controls...')
  
  const zoomPulsesBtn = document.getElementById('zoom-pulses')
  const zoomPixelsBtn = document.getElementById('zoom-pixels')
  const resetZoomBtn = document.getElementById('reset-zoom')
  const resetInteractiveBtn = document.getElementById('reset-interactive')

  if (zoomPulsesBtn) {
    zoomPulsesBtn.addEventListener('click', () => {
      canvasRenderer.zoomToPulses()
      signalGenerator.setTimeWindow(canvasRenderer.getTimeWindow())
    })
  }

  if (zoomPixelsBtn) {
    zoomPixelsBtn.addEventListener('click', () => {
      canvasRenderer.zoomToPixels()
      signalGenerator.setTimeWindow(canvasRenderer.getTimeWindow())
    })
  }

  if (resetZoomBtn) {
    resetZoomBtn.addEventListener('click', () => {
      canvasRenderer.resetZoom()
      signalGenerator.setTimeWindow(canvasRenderer.getTimeWindow())
    })
  }

  if (resetInteractiveBtn) {
    resetInteractiveBtn.addEventListener('click', () => {
      canvasRenderer.resetInteractiveMode()
      console.log('Interactive mode reset')
    })
  }
  
  console.log('Zoom controls setup complete')
}

function setupSignalTypeControl(): void {
  const signalTypeSelect = document.getElementById('signal-type') as HTMLSelectElement
  
  if (signalTypeSelect) {
    signalTypeSelect.addEventListener('change', () => {
      const signalType = signalTypeSelect.value as 'square' | 'sine'
      signalGenerator.setConfig({ signalType })
      console.log('Signal type changed to:', signalType)
    })
  }
}

function setupFileControls(): void {
  const loadBtn = document.getElementById('load-btn')
  const saveBtn = document.getElementById('save-btn')
  const loadFileInput = document.getElementById('load-file') as HTMLInputElement

  if (loadBtn && loadFileInput) {
    loadBtn.addEventListener('click', () => {
      loadFileInput.click()
    })

    loadFileInput.addEventListener('change', (event) => {
      const file = (event.target as HTMLInputElement).files?.[0]
      if (file) {
        loadSignalFile(file)
      }
    })
  }

  if (saveBtn) {
    saveBtn.addEventListener('click', () => {
      saveSignalFile()
    })
  }
}

function loadSignalFile(file: File): void {
  const reader = new FileReader()
  reader.onload = (e) => {
    try {
      const content = e.target?.result as string
      const signalData = parseSignalFile(content)
      
      if (signalData) {
        canvasRenderer.loadSignalData(signalData)
        console.log('Signal file loaded successfully:', file.name)
      } else {
        alert('Invalid signal file format')
      }
    } catch (error) {
      console.error('Error loading signal file:', error)
      alert('Error loading signal file: ' + error)
    }
  }
  reader.readAsText(file)
}

function parseSignalFile(content: string): any {
  const lines = content.trim().split('\n')
  const result: any = {}
  
  for (const line of lines) {
    const trimmedLine = line.trim()
    if (!trimmedLine) continue
    
    if (trimmedLine.startsWith('RPM:')) {
      result.rpm = parseInt(trimmedLine.substring(4))
    } else if (trimmedLine.startsWith('SignalType:')) {
      result.signalType = trimmedLine.substring(11)
    } else if (trimmedLine.startsWith('Crank:')) {
      const dataStr = trimmedLine.substring(6)
      const values = dataStr.split(',')
        .map(v => v.trim())
        .filter(v => v !== '')
        .map(v => parseInt(v))
        .filter(v => !isNaN(v))
      result.crank = values
    } else if (trimmedLine.startsWith('Cam1:')) {
      const dataStr = trimmedLine.substring(5)
      const values = dataStr.split(',')
        .map(v => v.trim())
        .filter(v => v !== '')
        .map(v => parseInt(v))
        .filter(v => !isNaN(v))
      result.cam1 = values
    } else if (trimmedLine.startsWith('Cam2:')) {
      const dataStr = trimmedLine.substring(5)
      const values = dataStr.split(',')
        .map(v => v.trim())
        .filter(v => v !== '')
        .map(v => parseInt(v))
        .filter(v => !isNaN(v))
      result.cam2 = values
    }
  }
  
  return result
}

function saveSignalFile(): void {
  const signalData = canvasRenderer.getSignalData()
  const config = signalGenerator.getConfig()
  
  let content = `RPM:${config.rpm}\n`
  content += `SignalType:${config.signalType}\n`
  content += `Crank:${signalData.crank.join(',')},\n`
  content += `Cam1:${signalData.cam1.join(',')},\n`
  content += `Cam2:${signalData.cam2.join(',')},\n`
  
  const blob = new Blob([content], { type: 'text/plain' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `signal_pattern_${Date.now()}.txt`
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  URL.revokeObjectURL(url)
  
  console.log('Signal file saved')
}

function setupHistoryControls(): void {
  const saveCurrentBtn = document.getElementById('save-current-btn')
  
  if (saveCurrentBtn) {
    saveCurrentBtn.addEventListener('click', () => {
      saveCurrentSignalToHistory()
    })
  }
  
  // Add clear log button handler
  const clearLogBtn = document.getElementById('clear-log-btn')
  if (clearLogBtn) {
    clearLogBtn.addEventListener('click', () => {
      if (signalTransmitter) {
        signalTransmitter.clearTransmissionLog()
      }
    })
  }
  
  loadSignalHistory()
  updateHistoryTable()
}

function saveCurrentSignalToHistory(): void {
  const brandSelect = document.getElementById('brand') as HTMLSelectElement
  const modelSelect = document.getElementById('model') as HTMLSelectElement
  const yearSelect = document.getElementById('year') as HTMLSelectElement
  const engineSelect = document.getElementById('engine') as HTMLSelectElement
  
  if (!brandSelect.value || !modelSelect.value || !yearSelect.value || !engineSelect.value) {
    alert('Please select complete vehicle information (Brand, Model, Year, Engine) before saving.')
    return
  }
  
  const signalData = canvasRenderer.getSignalData()
  const config = signalGenerator.getConfig()
  
  // Check for duplicate entries
  const isDuplicate = signalHistory.some(entry => 
    entry.brand === brandSelect.value &&
    entry.model === modelSelect.value &&
    entry.year === yearSelect.value &&
    entry.engine === engineSelect.value &&
    JSON.stringify(entry.signalData) === JSON.stringify(signalData) &&
    entry.config.rpm === config.rpm &&
    entry.config.signalType === config.signalType
  )
  
  if (isDuplicate) {
    alert('This signal pattern already exists in the history for the selected vehicle.')
    return
  }
  
  const entry: SignalHistoryEntry = {
    id: Date.now().toString(),
    brand: brandSelect.value,
    model: modelSelect.value,
    year: yearSelect.value,
    engine: engineSelect.value,
    timestamp: Date.now(),
    signalData: signalData,
    config: config
  }
  
  signalHistory.unshift(entry)
  
  if (signalHistory.length > 50) {
    signalHistory = signalHistory.slice(0, 50)
  }
  
  saveSignalHistory()
  updateHistoryTable()
  
  console.log('Signal pattern saved to history:', entry)
}

function saveSignalHistory(): void {
  try {
    localStorage.setItem('signalHistory', JSON.stringify(signalHistory))
  } catch (error) {
    console.error('Error saving signal history:', error)
  }
}

function loadSignalHistory(): void {
  try {
    const saved = localStorage.getItem('signalHistory')
    if (saved) {
      signalHistory = JSON.parse(saved)
    }
  } catch (error) {
    console.error('Error loading signal history:', error)
    signalHistory = []
  }
}

function updateHistoryTable(): void {
  const tbody = document.getElementById('history-tbody')
  if (!tbody) return
  
  tbody.innerHTML = ''
  
  signalHistory.forEach((entry, index) => {
    const row = document.createElement('tr')
    
    row.innerHTML = `
      <td class="vehicle-info">${entry.brand}</td>
      <td class="vehicle-info">${entry.model}</td>
      <td class="vehicle-info">${entry.year}</td>
      <td class="engine-info">${entry.engine}</td>
      <td><button class="table-btn btn-delete" onclick="deleteHistoryEntry('${entry.id}')">Delete</button></td>
      <td><button class="table-btn btn-download" onclick="downloadHistoryEntry('${entry.id}')">Download</button></td>
      <td><button class="table-btn btn-arduino" onclick="generateArduinoCode('${entry.id}')">Arduino</button></td>
      <td><button class="table-btn btn-esp32" onclick="generateESP32Code('${entry.id}')">ESP32</button></td>
    `
    
    tbody.appendChild(row)
  })
}

// Global functions for button clicks
;(window as any).deleteHistoryEntry = (id: string) => {
  signalHistory = signalHistory.filter(entry => entry.id !== id)
  saveSignalHistory()
  updateHistoryTable()
  console.log('History entry deleted:', id)
}

;(window as any).downloadHistoryEntry = (id: string) => {
  const entry = signalHistory.find(e => e.id === id)
  if (!entry) return
  
  let content = `RPM:${entry.config.rpm}\n`
  content += `SignalType:${entry.config.signalType}\n`
  content += `Crank:${entry.signalData.crank.join(',')},\n`
  content += `Cam1:${entry.signalData.cam1.join(',')},\n`
  content += `Cam2:${entry.signalData.cam2.join(',')},\n`
  
  const blob = new Blob([content], { type: 'text/plain' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `${entry.brand}_${entry.model}_${entry.year}_${entry.engine.replace(/[^a-zA-Z0-9]/g, '_')}.txt`
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  URL.revokeObjectURL(url)
  
  console.log('History entry downloaded:', entry)
}

;(window as any).generateArduinoCode = (id: string) => {
  const entry = signalHistory.find(e => e.id === id)
  if (!entry) return
  
  const arduinoCode = `
/*
  Automotive Signal Generator - Arduino Code
  Vehicle: ${entry.brand} ${entry.model} ${entry.year} ${entry.engine}
  Generated: ${new Date().toLocaleString()}
  Developer: SALAH ALRAWI
  Mobile: +964 781 156 6375
*/

#include <LiquidCrystal.h>

// LCD pins
LiquidCrystal lcd(12, 11, 5, 4, 3, 2);

// Signal output pins
const int CRANK_PIN = 8;
const int CAM1_PIN = 9;
const int CAM2_PIN = 10;

// Signal data
const int crankSignal[] = {${entry.signalData.crank.join(', ')}};
const int cam1Signal[] = {${entry.signalData.cam1.join(', ')}};
const int cam2Signal[] = {${entry.signalData.cam2.join(', ')}};

const int CRANK_SIZE = ${entry.signalData.crank.length};
const int CAM1_SIZE = ${entry.signalData.cam1.length};
const int CAM2_SIZE = ${entry.signalData.cam2.length};

// Timing variables
unsigned long lastUpdate = 0;
int currentIndex = 0;
const int RPM = ${entry.config.rpm};
const int DELAY_MS = 60000 / (RPM * max(CRANK_SIZE, max(CAM1_SIZE, CAM2_SIZE)));

void setup() {
  // Initialize LCD
  lcd.begin(16, 2);
  lcd.print("Signal Generator");
  lcd.setCursor(0, 1);
  lcd.print("${entry.brand} ${entry.model}");
  
  // Initialize pins
  pinMode(CRANK_PIN, OUTPUT);
  pinMode(CAM1_PIN, OUTPUT);
  pinMode(CAM2_PIN, OUTPUT);
  
  delay(2000);
  lcd.clear();
  lcd.print("RPM: ${entry.config.rpm}");
  lcd.setCursor(0, 1);
  lcd.print("Running...");
}

void loop() {
  unsigned long currentTime = millis();
  
  if (currentTime - lastUpdate >= DELAY_MS) {
    // Output crank signal
    if (currentIndex < CRANK_SIZE) {
      digitalWrite(CRANK_PIN, crankSignal[currentIndex] ? HIGH : LOW);
    }
    
    // Output cam1 signal
    if (currentIndex < CAM1_SIZE) {
      digitalWrite(CAM1_PIN, cam1Signal[currentIndex] ? HIGH : LOW);
    }
    
    // Output cam2 signal
    if (currentIndex < CAM2_SIZE) {
      digitalWrite(CAM2_PIN, cam2Signal[currentIndex] ? HIGH : LOW);
    }
    
    currentIndex++;
    if (currentIndex >= max(CRANK_SIZE, max(CAM1_SIZE, CAM2_SIZE))) {
      currentIndex = 0;
    }
    
    lastUpdate = currentTime;
  }
}
`
  
  const blob = new Blob([arduinoCode], { type: 'text/plain' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `${entry.brand}_${entry.model}_Arduino.ino`
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  URL.revokeObjectURL(url)
  
  console.log('Arduino code generated for:', entry)
}

;(window as any).generateESP32Code = (id: string) => {
  const entry = signalHistory.find(e => e.id === id)
  if (!entry) return
  
  const esp32Code = `
/*
  Automotive Signal Generator - ESP32 Code
  Vehicle: ${entry.brand} ${entry.model} ${entry.year} ${entry.engine}
  Generated: ${new Date().toLocaleString()}
  Developer: SALAH ALRAWI
  Mobile: +964 781 156 6375
*/

#include <WiFi.h>
#include <LiquidCrystal.h>
#include <SD.h>
#include <SPI.h>

// LCD pins
LiquidCrystal lcd(19, 23, 18, 17, 16, 15);

// Signal output pins
const int CRANK_PIN = 25;
const int CAM1_PIN = 26;
const int CAM2_PIN = 27;

// Control pins
const int BUTTON_NEXT = 32;
const int BUTTON_PREV = 33;
const int BUTTON_START = 34;
const int SD_CS_PIN = 5;

// Signal data
const int crankSignal[] = {${entry.signalData.crank.join(', ')}};
const int cam1Signal[] = {${entry.signalData.cam1.join(', ')}};
const int cam2Signal[] = {${entry.signalData.cam2.join(', ')}};

const int CRANK_SIZE = ${entry.signalData.crank.length};
const int CAM1_SIZE = ${entry.signalData.cam1.length};
const int CAM2_SIZE = ${entry.signalData.cam2.length};

// Timing variables
unsigned long lastUpdate = 0;
int currentIndex = 0;
const int RPM = ${entry.config.rpm};
const int DELAY_MS = 60000 / (RPM * max(CRANK_SIZE, max(CAM1_SIZE, CAM2_SIZE)));

bool isRunning = false;
int currentPattern = 0;
int totalPatterns = 1;

void setup() {
  Serial.begin(115200);
  
  // Initialize LCD
  lcd.begin(16, 2);
  lcd.print("ESP32 Signal Gen");
  lcd.setCursor(0, 1);
  lcd.print("Initializing...");
  
  // Initialize pins
  pinMode(CRANK_PIN, OUTPUT);
  pinMode(CAM1_PIN, OUTPUT);
  pinMode(CAM2_PIN, OUTPUT);
  pinMode(BUTTON_NEXT, INPUT_PULLUP);
  pinMode(BUTTON_PREV, INPUT_PULLUP);
  pinMode(BUTTON_START, INPUT_PULLUP);
  
  // Initialize SD card
  if (SD.begin(SD_CS_PIN)) {
    lcd.setCursor(0, 1);
    lcd.print("SD Card Ready   ");
    loadPatternsFromSD();
  } else {
    lcd.setCursor(0, 1);
    lcd.print("SD Card Failed  ");
  }
  
  delay(2000);
  updateDisplay();
}

void loop() {
  handleButtons();
  
  if (isRunning) {
    generateSignals();
  }
  
  // Handle serial communication for real-time updates
  if (Serial.available()) {
    handleSerialCommand();
  }
}

void handleButtons() {
  static unsigned long lastButtonPress = 0;
  unsigned long currentTime = millis();
  
  if (currentTime - lastButtonPress < 200) return; // Debounce
  
  if (digitalRead(BUTTON_NEXT) == LOW) {
    currentPattern = (currentPattern + 1) % totalPatterns;
    updateDisplay();
    lastButtonPress = currentTime;
  }
  
  if (digitalRead(BUTTON_PREV) == LOW) {
    currentPattern = (currentPattern - 1 + totalPatterns) % totalPatterns;
    updateDisplay();
    lastButtonPress = currentTime;
  }
  
  if (digitalRead(BUTTON_START) == LOW) {
    isRunning = !isRunning;
    updateDisplay();
    lastButtonPress = currentTime;
  }
}

void generateSignals() {
  unsigned long currentTime = millis();
  
  if (currentTime - lastUpdate >= DELAY_MS) {
    // Output crank signal
    if (currentIndex < CRANK_SIZE) {
      digitalWrite(CRANK_PIN, crankSignal[currentIndex] ? HIGH : LOW);
    }
    
    // Output cam1 signal
    if (currentIndex < CAM1_SIZE) {
      digitalWrite(CAM1_PIN, cam1Signal[currentIndex] ? HIGH : LOW);
    }
    
    // Output cam2 signal
    if (currentIndex < CAM2_SIZE) {
      digitalWrite(CAM2_PIN, cam2Signal[currentIndex] ? HIGH : LOW);
    }
    
    currentIndex++;
    if (currentIndex >= max(CRANK_SIZE, max(CAM1_SIZE, CAM2_SIZE))) {
      currentIndex = 0;
    }
    
    lastUpdate = currentTime;
  }
}

void updateDisplay() {
  lcd.clear();
  lcd.print("${entry.brand} ${entry.model}");
  lcd.setCursor(0, 1);
  if (isRunning) {
    lcd.print("Running RPM:${entry.config.rpm}");
  } else {
    lcd.print("Stopped RPM:${entry.config.rpm}");
  }
}

void loadPatternsFromSD() {
  // Load additional patterns from SD card
  File root = SD.open("/");
  if (root) {
    File file = root.openNextFile();
    while (file) {
      if (String(file.name()).endsWith(".txt")) {
        totalPatterns++;
      }
      file = root.openNextFile();
    }
    root.close();
  }
}

void handleSerialCommand() {
  String command = Serial.readStringUntil('\n');
  command.trim();
  
  if (command == "START") {
    isRunning = true;
    Serial.println("SIGNAL_STARTED");
  } else if (command == "STOP") {
    isRunning = false;
    Serial.println("SIGNAL_STOPPED");
  } else if (command.startsWith("SAVE:")) {
    String filename = command.substring(5);
    savePatternToSD(filename);
  }
  
  updateDisplay();
}

void savePatternToSD(String filename) {
  File file = SD.open("/" + filename, FILE_WRITE);
  if (file) {
    file.println("RPM:${entry.config.rpm}");
    file.println("SignalType:${entry.config.signalType}");
    file.print("Crank:");
    for (int i = 0; i < CRANK_SIZE; i++) {
      file.print(crankSignal[i]);
      if (i < CRANK_SIZE - 1) file.print(",");
    }
    file.println(",");
    
    file.print("Cam1:");
    for (int i = 0; i < CAM1_SIZE; i++) {
      file.print(cam1Signal[i]);
      if (i < CAM1_SIZE - 1) file.print(",");
    }
    file.println(",");
    
    file.print("Cam2:");
    for (int i = 0; i < CAM2_SIZE; i++) {
      file.print(cam2Signal[i]);
      if (i < CAM2_SIZE - 1) file.print(",");
    }
    file.println(",");
    
    file.close();
    Serial.println("PATTERN_SAVED:" + filename);
  } else {
    Serial.println("ERROR:Could not save pattern");
  }
}
`
  
  const blob = new Blob([esp32Code], { type: 'text/plain' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `${entry.brand}_${entry.model}_ESP32.ino`
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  URL.revokeObjectURL(url)
  
  console.log('ESP32 code generated for:', entry)
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  console.log('DOM loaded, initializing application...')
  init()
})

// Also initialize immediately if DOM is already loaded
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init)
} else {
  init()
}