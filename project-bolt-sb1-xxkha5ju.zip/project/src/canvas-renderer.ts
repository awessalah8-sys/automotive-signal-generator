import { SignalData } from './signal-generator'

export class CanvasRenderer {
  private combinedCanvas: HTMLCanvasElement
  private combinedCtx: CanvasRenderingContext2D
  private crankBoxes: HTMLElement
  private cam1Boxes: HTMLElement
  private cam2Boxes: HTMLElement

  // Store signal states for interaction
  private crankSignalState: number[] = new Array(400).fill(0)
  private cam1SignalState: number[] = new Array(400).fill(0)
  private cam2SignalState: number[] = new Array(400).fill(0)
  private crankDigitCount: number = 400
  private cam1DigitCount: number = 400
  private cam2DigitCount: number = 400
  private isInteractiveMode: boolean = false
  private zoomLevel: number = 1
  private timeWindow: number = 200 // Default time window in ms
  private isOscilloscopeMode: boolean = false
  private animationOffset: number = 0
  private oscilloscopeSpeed: number = 2 // pixels per frame

  constructor() {
    this.combinedCanvas = document.getElementById('combined-canvas') as HTMLCanvasElement
    this.combinedCtx = this.combinedCanvas.getContext('2d')!
    this.crankBoxes = document.getElementById('crank-boxes') as HTMLElement
    this.cam1Boxes = document.getElementById('cam1-boxes') as HTMLElement
    this.cam2Boxes = document.getElementById('cam2-boxes') as HTMLElement

    this.setupCanvases()
    this.setupPulseBoxes()
    this.setupOscilloscopeButton()
    
    // Delay button setup to ensure DOM is ready
    setTimeout(() => {
      this.setupControlButtons()
    }, 100)
  }

  private setupCanvases(): void {
    // Set up high DPI rendering
    const rect = this.combinedCanvas.getBoundingClientRect()
    const dpr = window.devicePixelRatio || 1
    
    this.combinedCanvas.width = rect.width * dpr
    this.combinedCanvas.height = rect.height * dpr
    
    this.combinedCtx.scale(dpr, dpr)
    this.combinedCanvas.style.width = rect.width + 'px'
    this.combinedCanvas.style.height = rect.height + 'px'

    // Set default styles
    this.combinedCtx.lineCap = 'round'
    this.combinedCtx.lineJoin = 'round'
  }

  private setupPulseBoxes(): void {
    // Create 400 boxes for each signal line
    this.createPulseBoxes(this.crankBoxes, this.crankDigitCount, 'crank')
    this.createPulseBoxes(this.cam1Boxes, this.cam1DigitCount, 'cam1')
    this.createPulseBoxes(this.cam2Boxes, this.cam2DigitCount, 'cam2')
  }

  private createPulseBoxes(container: HTMLElement, count: number, signalType: string): void {
    container.innerHTML = ''
    // Always create 400 boxes but only show the specified count
    for (let i = 0; i < 400; i++) {
      const box = document.createElement('div')
      box.className = 'pulse-box inactive'
      box.dataset.index = i.toString()
      box.dataset.signalType = signalType
      
      // Hide boxes beyond the specified count
      if (i >= count) {
        box.style.display = 'none'
      } else {
        box.style.display = 'flex'
      }
      
      // Add box number (1-based) directly to the box
      const boxNumber = i + 1
      box.textContent = boxNumber.toString()
      
      // Add number styling classes
      if (boxNumber % 2 === 1) {
        box.classList.add('odd-number')
      } else {
        box.classList.add('even-number')
      }
      
      // Add click event listener
      box.addEventListener('click', (e) => this.handleBoxClick(e, i, signalType))
      
      container.appendChild(box)
    }
  }

  private setupControlButtons(): void {
    // Add event listeners for all pulse control buttons
    const pulseButtons = document.querySelectorAll('.pulse-btn[data-signal][data-action]')
    
    pulseButtons.forEach(button => {
      button.addEventListener('click', (e) => {
        const target = e.target as HTMLElement
        const signal = target.dataset.signal
        const action = target.dataset.action
        
        console.log('Button clicked:', signal, action) // Debug log
        
        if (signal && action) {
          this.handleControlButtonClick(signal, action)
        }
      })
    })
    
    // Add event listeners for digit count inputs
    const digitCountInputs = document.querySelectorAll('.digit-count-input[data-signal]')
    
    digitCountInputs.forEach(input => {
      input.addEventListener('change', (e) => {
        const target = e.target as HTMLInputElement
        const signal = target.dataset.signal
        const count = parseInt(target.value)
        
        console.log('Digit count changed:', signal, count) // Debug log
        
        if (signal && count >= 1 && count <= 400) {
          this.handleDigitCountChange(signal, count)
        }
      })
    })
    
    console.log('Found', pulseButtons.length, 'pulse control buttons') // Debug log
    console.log('Found', digitCountInputs.length, 'digit count inputs') // Debug log
  }

  private setupOscilloscopeButton(): void {
    const oscilloscopeBtn = document.getElementById('oscilloscope-btn')
    if (oscilloscopeBtn) {
      oscilloscopeBtn.addEventListener('click', () => {
        this.toggleOscilloscopeMode()
      })
      console.log('Oscilloscope button event listener added')
    } else {
      console.error('Oscilloscope button not found in DOM')
    }
  }

  public toggleOscilloscopeMode(): void {
    this.isOscilloscopeMode = !this.isOscilloscopeMode
    const btn = document.getElementById('oscilloscope-btn') as HTMLButtonElement
    
    if (this.isOscilloscopeMode) {
      btn.textContent = '⏹️ Stop Oscilloscope'
      btn.classList.add('active')
      this.startOscilloscopeAnimation()
      console.log('Oscilloscope mode enabled - signals will scroll like real oscilloscope')
    } else {
      btn.textContent = '📺 Oscilloscope Mode'
      btn.classList.remove('active')
      this.animationOffset = 0
      console.log('Oscilloscope mode disabled')
    }
    
    // Force re-render to show changes immediately
    if (this.isInteractiveMode) {
      this.renderInteractiveSignals()
    }
  }

  private startOscilloscopeAnimation(): void {
    if (!this.isOscilloscopeMode) return
    
    this.animationOffset += this.oscilloscopeSpeed
    
    // Reset offset when it gets too large
    if (this.animationOffset > 1000) {
      this.animationOffset = 0
    }
    
    // Re-render with new offset
    if (this.isInteractiveMode) {
      this.renderInteractiveSignals()
    }
    
    // Continue animation
    requestAnimationFrame(() => this.startOscilloscopeAnimation())
  }

  private handleControlButtonClick(signal: string, action: string): void {
    console.log('Handling control button click:', signal, action) // Debug log
    
    // Enable interactive mode if not already enabled
    if (!this.isInteractiveMode) {
      this.isInteractiveMode = true
      console.log('Interactive mode enabled via control button')
    }
    
    // Get the appropriate signal state array and digit count
    let signalState: number[]
    let digitCount: number
    switch (signal) {
      case 'crank':
        signalState = this.crankSignalState
        digitCount = this.crankDigitCount
        break
      case 'cam1':
        signalState = this.cam1SignalState
        digitCount = this.cam1DigitCount
        break
      case 'cam2':
        signalState = this.cam2SignalState
        digitCount = this.cam2DigitCount
        break
      default:
        console.log('Unknown signal type:', signal)
        return
    }
    
    // Apply the action
    switch (action) {
      case 'odd':
        // Set odd-numbered positions (1, 3, 5, ...) to 1
        signalState.fill(0) // Clear all first
        for (let i = 0; i < digitCount; i++) {
          const boxNumber = i + 1 // Box numbers are 1-based
          if (boxNumber % 2 === 1) { // Odd numbers
            signalState[i] = 1
          }
        }
        console.log('Applied odd action to', signal)
        break
      case 'all':
        // Set all positions to 1
        for (let i = 0; i < digitCount; i++) {
          signalState[i] = 1
        }
        console.log('Applied all action to', signal)
        break
      case 'zero':
        // Set all positions to 0
        for (let i = 0; i < digitCount; i++) {
          signalState[i] = 0
        }
        console.log('Applied zero action to', signal)
        break
      default:
        console.log('Unknown action:', action)
        return
    }
    
    // Update display immediately
    this.renderInteractiveSignals()
    this.updateBoxesFromState()
    console.log('Updated display for', signal, 'with action', action)
  }

  public getSignalData(): { crank: number[], cam1: number[], cam2: number[] } {
    return {
      crank: [...this.crankSignalState],
      cam1: [...this.cam1SignalState],
      cam2: [...this.cam2SignalState]
    }
  }

  public loadSignalData(signalData: { [key: string]: number[] }): void {
    // Enable interactive mode
    this.isInteractiveMode = true
    
    // Load crank data
    if (signalData.crank && Array.isArray(signalData.crank)) {
      this.crankDigitCount = signalData.crank.length
      this.crankSignalState = [...signalData.crank]
      this.createPulseBoxes(this.crankBoxes, this.crankDigitCount, 'crank')
      
      // Update digit count input
      const crankInput = document.querySelector('.digit-count-input[data-signal="crank"]') as HTMLInputElement
      if (crankInput) crankInput.value = this.crankDigitCount.toString()
    }
    
    // Load cam1 data
    if (signalData.cam1 && Array.isArray(signalData.cam1)) {
      this.cam1DigitCount = signalData.cam1.length
      this.cam1SignalState = [...signalData.cam1]
      this.createPulseBoxes(this.cam1Boxes, this.cam1DigitCount, 'cam1')
      
      // Update digit count input
      const cam1Input = document.querySelector('.digit-count-input[data-signal="cam1"]') as HTMLInputElement
      if (cam1Input) cam1Input.value = this.cam1DigitCount.toString()
    }
    
    // Load cam2 data
    if (signalData.cam2 && Array.isArray(signalData.cam2)) {
      this.cam2DigitCount = signalData.cam2.length
      this.cam2SignalState = [...signalData.cam2]
      this.createPulseBoxes(this.cam2Boxes, this.cam2DigitCount, 'cam2')
      
      // Update digit count input
      const cam2Input = document.querySelector('.digit-count-input[data-signal="cam2"]') as HTMLInputElement
      if (cam2Input) cam2Input.value = this.cam2DigitCount.toString()
    }
    
    // Update display
    this.renderInteractiveSignals()
    this.updateBoxesFromState()
    
    console.log('Signal data loaded successfully')
  }

  private handleDigitCountChange(signal: string, count: number): void {
    console.log('Handling digit count change:', signal, count)
    
    // Limit count to maximum of 400
    count = Math.min(count, 400)
    
    // Update the digit count and show/hide boxes accordingly
    let container: HTMLElement
    switch (signal) {
      case 'crank':
        this.crankDigitCount = count
        // Resize signal state array to match new count, preserving existing values
        const newCrankState = new Array(400).fill(0)
        for (let i = 0; i < Math.min(count, this.crankSignalState.length); i++) {
          newCrankState[i] = this.crankSignalState[i]
        }
        this.crankSignalState = newCrankState
        container = this.crankBoxes
        break
      case 'cam1':
        this.cam1DigitCount = count
        const newCam1State = new Array(400).fill(0)
        for (let i = 0; i < Math.min(count, this.cam1SignalState.length); i++) {
          newCam1State[i] = this.cam1SignalState[i]
        }
        this.cam1SignalState = newCam1State
        container = this.cam1Boxes
        break
      case 'cam2':
        this.cam2DigitCount = count
        const newCam2State = new Array(400).fill(0)
        for (let i = 0; i < Math.min(count, this.cam2SignalState.length); i++) {
          newCam2State[i] = this.cam2SignalState[i]
        }
        this.cam2SignalState = newCam2State
        container = this.cam2Boxes
        break
      default:
        console.log('Unknown signal type:', signal)
        return
    }
    
    // Show/hide boxes based on the new count
    const boxes = container.children
    for (let i = 0; i < boxes.length; i++) {
      const box = boxes[i] as HTMLElement
      if (i < count) {
        box.style.display = 'flex'
      } else {
        box.style.display = 'none'
      }
    }
    
    // Enable interactive mode if not already enabled
    if (!this.isInteractiveMode) {
      this.isInteractiveMode = true
      console.log('Interactive mode enabled via digit count change')
    }
    
    // Update display immediately
    this.renderInteractiveSignals()
    console.log('Updated', signal, 'to use', count, 'digits')
  }

  private handleBoxClick(event: Event, index: number, signalType: string): void {
    event.preventDefault()
    
    // Toggle interactive mode on first click
    if (!this.isInteractiveMode) {
      this.isInteractiveMode = true
      console.log('Interactive mode enabled')
    }
    
    // Toggle the signal state
    let signalState: number[]
    switch (signalType) {
      case 'crank':
        signalState = this.crankSignalState
        break
      case 'cam1':
        signalState = this.cam1SignalState
        break
      case 'cam2':
        signalState = this.cam2SignalState
        break
      default:
        return
    }
    
    // Toggle between 0 and 1
    signalState[index] = signalState[index] === 0 ? 1 : 0
    
    // Update display immediately
    this.renderInteractiveSignals()
    this.updateBoxesFromState()
  }

  private renderInteractiveSignals(): void {
    const canvas = this.combinedCanvas
    const width = canvas.width / (window.devicePixelRatio || 1)
    const height = canvas.height / (window.devicePixelRatio || 1)
    const ctx = this.combinedCtx

    // Clear canvas
    ctx.fillStyle = '#1a1a1a'
    ctx.fillRect(0, 0, width, height)

    // Draw grid
    this.drawGrid(ctx, width, height, this.isOscilloscopeMode ? this.animationOffset : 0)

    // Calculate signal heights - make them closer together
    const totalSignalArea = height * 0.6  // Use less vertical space
    const signalSpacing = totalSignalArea / 3
    const topMargin = height * 0.2  // More top margin
    const amplitude = signalSpacing * 0.8  // Larger amplitude for better visibility
    
    // Draw signals from stored states
    const offset = this.isOscilloscopeMode ? this.animationOffset : 0
    this.drawSignal(ctx, this.crankSignalState, '#00ff41', topMargin, signalSpacing, amplitude, width, offset)
    this.drawSignal(ctx, this.cam1SignalState, '#ff6b35', topMargin + signalSpacing, signalSpacing, amplitude, width, offset)
    this.drawSignal(ctx, this.cam2SignalState, '#4ecdc4', topMargin + signalSpacing * 2, signalSpacing, amplitude, width, offset)
    
    // Draw section dividers
    ctx.strokeStyle = '#444'
    ctx.lineWidth = 1
    ctx.setLineDash([3, 3])
    ctx.beginPath()
    ctx.moveTo(0, topMargin + signalSpacing)
    ctx.lineTo(width, topMargin + signalSpacing)
    ctx.moveTo(0, topMargin + signalSpacing * 2)
    ctx.lineTo(width, topMargin + signalSpacing * 2)
    ctx.stroke()
    ctx.setLineDash([])
    
    // Draw voltage level indicators
    ctx.fillStyle = '#888'
    ctx.font = '10px monospace'
    ctx.textAlign = 'left'
    ctx.fillText('5V', 5, topMargin + 15)
    ctx.fillText('0V', 5, topMargin + signalSpacing - 5)
    ctx.fillText('5V', 5, topMargin + signalSpacing + 15)
    ctx.fillText('0V', 5, topMargin + signalSpacing * 2 - 5)
    ctx.fillText('5V', 5, topMargin + signalSpacing * 2 + 15)
    ctx.fillText('0V', 5, height - 5)
  }

  private renderOscilloscopeSignals(): void {
    const canvas = this.combinedCanvas
    const width = canvas.width / (window.devicePixelRatio || 1)
    const height = canvas.height / (window.devicePixelRatio || 1)
    const ctx = this.combinedCtx

    // Clear canvas with oscilloscope-style background
    ctx.fillStyle = '#0a0a0a'
    ctx.fillRect(0, 0, width, height)
  }
  private updateBoxesFromState(): void {
    this.updateSignalBoxesFromState(this.crankBoxes, this.crankSignalState)
    this.updateSignalBoxesFromState(this.cam1Boxes, this.cam1SignalState)
    this.updateSignalBoxesFromState(this.cam2Boxes, this.cam2SignalState)
  }

  private updateSignalBoxesFromState(container: HTMLElement, signalState: number[]): void {
    const boxes = container.children
    
    for (let i = 0; i < boxes.length; i++) {
      const box = boxes[i] as HTMLElement
      
      // Only update visible boxes
      if (box.style.display !== 'none' && i < signalState.length) {
        const value = signalState[i]
        
        if (value === 1) {
          box.className = 'pulse-box active'
        } else {
          box.className = 'pulse-box inactive'
        }
      } else {
        box.className = 'pulse-box inactive'
      }
    }
  }

  public resetInteractiveMode(): void {
    this.isInteractiveMode = false
    this.isOscilloscopeMode = false
    this.animationOffset = 0
    
    // Reset oscilloscope button
    const btn = document.getElementById('oscilloscope-btn') as HTMLButtonElement
    if (btn) {
      btn.textContent = '📺 Oscilloscope Mode'
      btn.classList.remove('active')
    }
    
    this.crankSignalState = new Array(this.crankDigitCount).fill(0)
    this.cam1SignalState = new Array(this.cam1DigitCount).fill(0)
    this.cam2SignalState = new Array(this.cam2DigitCount).fill(0)
    
    // Reset digit count inputs to default values
    const crankInput = document.querySelector('.digit-count-input[data-signal="crank"]') as HTMLInputElement
    const cam1Input = document.querySelector('.digit-count-input[data-signal="cam1"]') as HTMLInputElement
    const cam2Input = document.querySelector('.digit-count-input[data-signal="cam2"]') as HTMLInputElement
    
    if (crankInput) crankInput.value = '250'
    if (cam1Input) cam1Input.value = '250'
    if (cam2Input) cam2Input.value = '250'
    
    
    // Recreate boxes with default count
    this.setupPulseBoxes()
    this.clearAll()
  }

  public zoomToPulses(): void {
    this.zoomLevel = 4
    this.timeWindow = 50 // Show fewer pulses but larger
    if (this.isInteractiveMode) {
      this.renderInteractiveSignals()
    }
    console.log('Zoomed to pulse level - showing individual pulses clearly')
  }

  public zoomToPixels(): void {
    this.zoomLevel = 8
    this.timeWindow = 25 // Maximum zoom for pixel-level detail
    if (this.isInteractiveMode) {
      this.renderInteractiveSignals()
    }
    console.log('Zoomed to pixel level - maximum detail')
  }

  public resetZoom(): void {
    this.zoomLevel = 1
    this.timeWindow = 200 // Default view
    if (this.isInteractiveMode) {
      this.renderInteractiveSignals()
    }
    console.log('Zoom reset to default level')
  }

  public getTimeWindow(): number {
    return this.timeWindow
  }

  public renderSignals(data: SignalData): void {
    if (!this.isInteractiveMode) {
      this.renderCombinedSignals(data)
      this.updatePulseBoxes(data)
    } else {
      // In interactive mode, render from stored states
      if (this.isOscilloscopeMode) {
        this.renderOscilloscopeSignals()
      } else {
        this.renderInteractiveSignals()
      }
      this.updateBoxesFromState()
    }
  }

  private renderCombinedSignals(data: SignalData): void {
    const canvas = this.combinedCanvas
    const width = canvas.width / (window.devicePixelRatio || 1)
    const height = canvas.height / (window.devicePixelRatio || 1)
    const ctx = this.combinedCtx

    // Clear canvas
    ctx.fillStyle = '#1a1a1a'
    ctx.fillRect(0, 0, width, height)

    // Draw grid
    this.drawGrid(ctx, width, height, this.isOscilloscopeMode ? this.animationOffset : 0)

    // Calculate signal heights - make them closer together
    const totalSignalArea = height * 0.8 // Use 80% of canvas height
    const signalSpacing = totalSignalArea / 3
    const topMargin = height * 0.1 // 10% margin at top
    const amplitude = signalSpacing * 0.6 // Larger amplitude for better visibility
    
    // Draw signals closer together
    const offset = this.isOscilloscopeMode ? this.animationOffset : 0
    this.drawSignal(ctx, data.crank, '#00ff41', topMargin, signalSpacing, amplitude, width, offset)
    this.drawSignal(ctx, data.cam1, '#ff6b35', topMargin + signalSpacing, signalSpacing, amplitude, width, offset)
    this.drawSignal(ctx, data.cam2, '#4ecdc4', topMargin + signalSpacing * 2, signalSpacing, amplitude, width, offset)
    
    // Draw very subtle section dividers between signals
    ctx.strokeStyle = '#2a2a2a'
    ctx.lineWidth = 0.5
    ctx.setLineDash([2, 4])
    ctx.beginPath()
    ctx.moveTo(0, topMargin + signalSpacing)
    ctx.lineTo(width, topMargin + signalSpacing)
    ctx.moveTo(0, topMargin + signalSpacing * 2)
    ctx.lineTo(width, topMargin + signalSpacing * 2)
    ctx.stroke()
    ctx.setLineDash([])
    
    // Draw voltage level indicators
    ctx.fillStyle = '#888'
    ctx.font = '10px monospace'
    ctx.textAlign = 'left'
    ctx.fillText('5V', 5, topMargin + 15)
    ctx.fillText('0V', 5, topMargin + signalSpacing - 10)
    ctx.fillText('5V', 5, topMargin + signalSpacing + 15)
    ctx.fillText('0V', 5, topMargin + signalSpacing * 2 - 10)
    ctx.fillText('5V', 5, topMargin + signalSpacing * 2 + 15)
    ctx.fillText('0V', 5, topMargin + totalSignalArea - 5)
  }

  private drawSignal(
    ctx: CanvasRenderingContext2D,
    signal: number[],
    color: string,
    yOffset: number,
    sectionHeight: number,
    amplitude: number,
    width: number,
    animationOffset: number = 0
  ): void {
    ctx.strokeStyle = color
    ctx.lineWidth = 2  // Slightly thicker lines for better visibility
    ctx.beginPath()

    // Apply zoom level to step size
    const stepX = (width / signal.length) * this.zoomLevel
    const baseline = yOffset + sectionHeight * 0.85  // Move baseline lower for tighter spacing

    // Adjust visible range based on zoom
    const visibleSamples = Math.min(signal.length, Math.floor(signal.length / this.zoomLevel))
    
    // Apply animation offset for oscilloscope effect
    const offsetSamples = Math.floor(animationOffset / stepX)
    
    for (let i = 0; i < visibleSamples; i++) {
      const sampleIndex = (i + offsetSamples) % signal.length
      const x = (i * stepX) - (animationOffset % stepX)
      const y = baseline - (signal[sampleIndex] * amplitude)

      if (i === 0) {
        ctx.moveTo(x, y)
      } else {
        ctx.lineTo(x, y)
      }
    }

    ctx.stroke()

    // Draw baseline
    ctx.strokeStyle = '#333'
    ctx.lineWidth = 0.5
    ctx.setLineDash([3, 3])
    ctx.beginPath()
    ctx.moveTo(-animationOffset, baseline)
    ctx.lineTo(Math.min(width, visibleSamples * stepX), baseline)
    ctx.stroke()
    ctx.setLineDash([])
  }

  private drawGrid(ctx: CanvasRenderingContext2D, width: number, height: number): void {
  }
  private drawGrid(ctx: CanvasRenderingContext2D, width: number, height: number, animationOffset: number = 0): void {
    ctx.strokeStyle = '#333'
    ctx.lineWidth = 0.5

    // Vertical grid lines with animation offset
    const verticalLines = Math.floor(40 * this.zoomLevel) // More grid lines when zoomed
    for (let i = 0; i <= verticalLines; i++) {
      const x = ((i / verticalLines) * width - animationOffset) % width
      if (x < 0) continue // Skip lines that are off-screen
      ctx.beginPath()
      ctx.moveTo(x, 0)
      ctx.lineTo(x, height)
      ctx.stroke()
    }

    // Horizontal grid lines
    const horizontalLines = 16
    for (let i = 0; i <= horizontalLines; i++) {
      const y = (i / horizontalLines) * height
      ctx.beginPath()
      ctx.moveTo(0, y)
      ctx.lineTo(width, y)
      ctx.stroke()
    }
  }

  public clearAll(): void {
    const canvas = this.combinedCanvas
    const width = canvas.width / (window.devicePixelRatio || 1)
    const height = canvas.height / (window.devicePixelRatio || 1)
    
    this.combinedCtx.fillStyle = '#1a1a1a'
    this.combinedCtx.fillRect(0, 0, width, height)
    this.drawGrid(this.combinedCtx, width, height, 0)
  }

  private updatePulseBoxes(data: SignalData): void {
    this.updateSignalBoxes(this.crankBoxes, data.crank)
    this.updateSignalBoxes(this.cam1Boxes, data.cam1)
    this.updateSignalBoxes(this.cam2Boxes, data.cam2)
  }

  private updateSignalBoxes(container: HTMLElement, signal: number[]): void {
    const boxes = container.children
    const boxCount = boxes.length
    const signalLength = signal.length
    
    // Map signal data to boxes
    for (let i = 0; i < boxCount; i++) {
      const signalIndex = Math.floor((i / boxCount) * signalLength)
      const value = signal[signalIndex] || 0
      const box = boxes[i] as HTMLElement
      
      // Set binary value (0 or 1) based on signal threshold
      const binaryValue = value > 0.5 ? 1 : 0
      
      if (binaryValue === 1) {
        box.className = 'pulse-box active'
      } else {
        box.className = 'pulse-box inactive'
      }
    }
  }
}