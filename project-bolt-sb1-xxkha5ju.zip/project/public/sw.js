const CACHE_NAME = 'automotive-signal-generator-v1.0.0';
const STATIC_CACHE_URLS = [
  '/',
  '/index.html',
  '/src/main.ts',
  '/src/style.css',
  '/src/signal-generator.ts',
  '/src/canvas-renderer.ts',
  '/src/ui-controller.ts',
  '/src/vehicle-data.ts',
  '/src/signal-transmitter.ts',
  '/src/signal-plotter.ts'
];

// Install event - cache static resources
self.addEventListener('install', (event) => {
  console.log('Service Worker: Installing...');
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('Service Worker: Caching static files');
        return cache.addAll(STATIC_CACHE_URLS);
      })
      .then(() => {
        console.log('Service Worker: Installation complete');
        return self.skipWaiting();
      })
      .catch((error) => {
        console.error('Service Worker: Installation failed', error);
      })
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', (event) => {
  console.log('Service Worker: Activating...');
  event.waitUntil(
    caches.keys()
      .then((cacheNames) => {
        return Promise.all(
          cacheNames.map((cacheName) => {
            if (cacheName !== CACHE_NAME) {
              console.log('Service Worker: Deleting old cache', cacheName);
              return caches.delete(cacheName);
            }
          })
        );
      })
      .then(() => {
        console.log('Service Worker: Activation complete');
        return self.clients.claim();
      })
  );
});

// Fetch event - serve from cache, fallback to network
self.addEventListener('fetch', (event) => {
  // Skip non-GET requests
  if (event.request.method !== 'GET') {
    return;
  }

  // Skip chrome-extension and other non-http requests
  if (!event.request.url.startsWith('http')) {
    return;
  }

  event.respondWith(
    caches.match(event.request)
      .then((cachedResponse) => {
        // Return cached version if available
        if (cachedResponse) {
          console.log('Service Worker: Serving from cache', event.request.url);
          return cachedResponse;
        }

        // Otherwise fetch from network
        console.log('Service Worker: Fetching from network', event.request.url);
        return fetch(event.request)
          .then((response) => {
            // Don't cache non-successful responses
            if (!response || response.status !== 200 || response.type !== 'basic') {
              return response;
            }

            // Clone the response for caching
            const responseToCache = response.clone();

            // Cache dynamic content
            caches.open(CACHE_NAME)
              .then((cache) => {
                cache.put(event.request, responseToCache);
              });

            return response;
          })
          .catch((error) => {
            console.error('Service Worker: Fetch failed', error);
            
            // Return offline fallback for navigation requests
            if (event.request.destination === 'document') {
              return caches.match('/index.html');
            }
            
            throw error;
          });
      })
  );
});

// Background sync for offline signal data
self.addEventListener('sync', (event) => {
  console.log('Service Worker: Background sync triggered', event.tag);
  
  if (event.tag === 'sync-signal-data') {
    event.waitUntil(
      syncSignalData()
    );
  }
});

// Push notifications for ESP32 connection status
self.addEventListener('push', (event) => {
  console.log('Service Worker: Push notification received');
  
  const options = {
    body: event.data ? event.data.text() : 'Signal Generator notification',
    icon: 'https://images.pexels.com/photos/190574/pexels-photo-190574.jpeg?auto=compress&cs=tinysrgb&w=192&h=192&fit=crop',
    badge: 'https://images.pexels.com/photos/190574/pexels-photo-190574.jpeg?auto=compress&cs=tinysrgb&w=72&h=72&fit=crop',
    vibrate: [200, 100, 200],
    tag: 'signal-generator',
    requireInteraction: true,
    actions: [
      {
        action: 'open',
        title: 'Open App',
        icon: 'https://images.pexels.com/photos/190574/pexels-photo-190574.jpeg?auto=compress&cs=tinysrgb&w=48&h=48&fit=crop'
      }
    ]
  };

  event.waitUntil(
    self.registration.showNotification('Automotive Signal Generator', options)
  );
});

// Handle notification clicks
self.addEventListener('notificationclick', (event) => {
  console.log('Service Worker: Notification clicked');
  
  event.notification.close();
  
  if (event.action === 'open' || !event.action) {
    event.waitUntil(
      clients.openWindow('/')
    );
  }
});

// Sync signal data function
async function syncSignalData() {
  try {
    console.log('Service Worker: Syncing signal data...');
    
    // Get stored signal data from IndexedDB
    const signalData = await getStoredSignalData();
    
    if (signalData && signalData.length > 0) {
      // Attempt to sync with server or ESP32
      const response = await fetch('/api/sync-signals', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(signalData)
      });
      
      if (response.ok) {
        console.log('Service Worker: Signal data synced successfully');
        await clearStoredSignalData();
      }
    }
  } catch (error) {
    console.error('Service Worker: Signal data sync failed', error);
  }
}

// Helper function to get stored signal data
async function getStoredSignalData() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('SignalGeneratorDB', 1);
    
    request.onerror = () => reject(request.error);
    
    request.onsuccess = () => {
      const db = request.result;
      const transaction = db.transaction(['signalData'], 'readonly');
      const store = transaction.objectStore('signalData');
      const getAllRequest = store.getAll();
      
      getAllRequest.onsuccess = () => resolve(getAllRequest.result);
      getAllRequest.onerror = () => reject(getAllRequest.error);
    };
    
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains('signalData')) {
        db.createObjectStore('signalData', { keyPath: 'id', autoIncrement: true });
      }
    };
  });
}

// Helper function to clear stored signal data
async function clearStoredSignalData() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('SignalGeneratorDB', 1);
    
    request.onsuccess = () => {
      const db = request.result;
      const transaction = db.transaction(['signalData'], 'readwrite');
      const store = transaction.objectStore('signalData');
      const clearRequest = store.clear();
      
      clearRequest.onsuccess = () => resolve();
      clearRequest.onerror = () => reject(clearRequest.error);
    };
  });
}